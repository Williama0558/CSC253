﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeInformation
{
    // An abstract class that will be used to provide information to two subclasses
    public abstract class BaseEmployee
    {
        // Fields
        private string _firstName;
        private string _lastName;
        private string _phoneNumber;
        private string _email;

        // Constructor 
        public BaseEmployee(string firstName, string lastName, string phoneNumber, string email)
        {
            _firstName = firstName;
            _lastName = lastName;
            _phoneNumber = phoneNumber;
            _email = email;
        }

        // No-arg constructor that was created so that any subclasses can be instantiated without having to provide arguments
        public BaseEmployee()
        {
            _firstName = "";
            _lastName = "";
            _phoneNumber = "";
            _email = "";
        }

        // Methods to get information to store in the class
        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }

        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }

        public string PhoneNumber
        {
            get { return _phoneNumber; }
            set { _phoneNumber = value; }
        }

        // Method that will be overwritten by subclasses so that they can format their emails in different ways
        public virtual string Email
        {
            get { return _email + ""; }
            set { _email = value;  }
        }
    }
}
