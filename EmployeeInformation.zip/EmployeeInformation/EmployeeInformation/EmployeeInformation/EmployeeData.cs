﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeInformation
{
    public partial class EmployeeData : Form
    {
        public EmployeeData()
        {
            InitializeComponent();
        }

        private void checkPasswordButton_Click(object sender, EventArgs e)
        {
            string userPassword = passwordTextBox.Text;
            char letter;

            // Boolean variables that will be used to make sure the password matches the criteria.
            Boolean uppercase = false;
            Boolean lowercase = false;
            Boolean digit = false;

            // Any password entered must be at least 8 characters long or else it is immediately invalid
            if (userPassword.Length >= 8)
            {
                // For every character in the string the user entered, it will check if it: uppercase, lowercase, or a digit.
                // All three must be true to be valid.
                for (int index = 0; index < userPassword.Length; index++)
                {
                    letter = userPassword[index];
                    if (char.IsUpper(letter))
                    {
                        uppercase = true;
                    }
                    else if (char.IsLower(letter))
                    {
                        lowercase = true;
                    }
                    else if (char.IsDigit(letter))
                    {
                        digit = true;
                    }

                }
                
                // Checks to see if a password is valid by using boolean values that were created earlier in the program.
                // Will check for: if there were any uppercase or lowercase characters as well as digits.
                if (uppercase == true && lowercase == true && digit == true)
                {
                    MessageBox.Show("Valid password entered.");
                }
                if (uppercase == false)
                {
                    MessageBox.Show("No uppercase letters entered.");
                }
                if (lowercase == false)
                {
                    MessageBox.Show("No lowercase letters entered.");
                }
                if (digit == false)
                {
                    MessageBox.Show("No digits entered.");
                }
            }
            else
            {
                MessageBox.Show("Invalid password length");
            }


        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
