﻿/**
* 11/8/18
* CSC 253
* Aaron Williams
* This program reads employee information from a file and displays it in a second form. The information read from the file will be stored in classes that are subclasses
* of an abstract class. It will also allow the user to enter a password and will check to see if it is valid.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace EmployeeInformation
{

    public partial class EmployeeList : Form
    {
        // This list will accept objects that are created from subclasses of the BaseEmployee class 
        // so that they can be displayed in a listbox
        List<BaseEmployee> employeeList = new List<BaseEmployee>();

        public EmployeeList()
        {
            InitializeComponent();
        }

        private void EmployeeList_Load(object sender, EventArgs e)
        {
            // Reads file
            StreamReader inputFile = new StreamReader("employees.csv");

            // Dictionary for spliting strings
            char[] delim = { ',', '.' };
            
            // Holds the position of a worker so that it can used to make sure the worker gets the right email format
            string position;

            // Runs through file and adds info to fields in the structure
            while (!inputFile.EndOfStream)
            {
                string employeeInfoLine = inputFile.ReadLine();
                string[] splitEmployeeLine = employeeInfoLine.Split(delim);
                position = splitEmployeeLine[4];

                // This if-else statement will check to see if an employee is a regular employee or a manager
                // Depending on their position, the way their email is formatted will change.
                if (position == "Staff")
                {
                    // Creates a new Employee object and reads information from a file to store in the object.
                    Employee workerInfo = new Employee();
                    workerInfo.FirstName = splitEmployeeLine[0].Substring(0, 1).ToUpper() + splitEmployeeLine[0].Substring(1);
                    workerInfo.LastName = splitEmployeeLine[1].Substring(0, 1).ToUpper() + splitEmployeeLine[1].Substring(1);
                    workerInfo.PhoneNumber = splitEmployeeLine[2];
                    workerInfo.Email = workerInfo.LastName + workerInfo.FirstName.Remove(1);

                    // Adds the object to a list so that its data can be retrieved if the need arises
                    employeeList.Add(workerInfo);

                    // Adds the name properties of an object to listbox so that they can be displayed
                    employeeNameListBox.Items.Add(workerInfo.LastName + ", "  + workerInfo.FirstName);
                }
                else
                {
                    // Creates a new Manager object and reads information from a file to store in the object.
                    Manager managerInfo = new Manager();
                    managerInfo.FirstName = splitEmployeeLine[0].Substring(0, 1).ToUpper() + splitEmployeeLine[0].Substring(1);
                    managerInfo.LastName = splitEmployeeLine[1].Substring(0, 1).ToUpper() + splitEmployeeLine[1].Substring(1);
                    managerInfo.PhoneNumber = splitEmployeeLine[2];
                    managerInfo.Email = managerInfo.LastName + managerInfo.FirstName.Remove(1);

                    // Adds the object to a list so that its data can be retrieved if the need arises
                    employeeList.Add(managerInfo);

                    // Adds the name properties of an object to listbox so that they can be displayed
                    employeeNameListBox.Items.Add(managerInfo.LastName + ", " + managerInfo.FirstName);
                }
            }
        }

        private void viewButton_Click(object sender, EventArgs e)
        {
            char[] delim = { ','};
            EmployeeData employeeData = new EmployeeData();

            // Lets user pick a name and then displays the info on a second form.
            if (employeeNameListBox.SelectedIndex != -1)
            {
                // Depending on the index of the listbox option the user selects, it will display the info of the person who's info is in that index.
                int index = employeeNameListBox.SelectedIndex;
                employeeData.firstNameTextBox.Text = employeeList[index].FirstName;
                employeeData.lastNameTextBox.Text = employeeList[index].LastName;
                employeeData.phoneNumberTextBox.Text = employeeList[index].PhoneNumber;
                employeeData.emailTextBox.Text = employeeList[index].Email;
                employeeData.ShowDialog();

            }
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            // Closes the program
            this.Close();
        }
    }
}
