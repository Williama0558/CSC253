﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeInformation
{
    // This class is a subclass of the BaseEmployee class. It is mostly the same as its base class,
    // except it overrides the base class' Email method
    class Employee : BaseEmployee
    {
        public Employee(string firstName, string lastName, string phoneNumber, string email) : base(firstName, lastName, phoneNumber, email)
        {

        }

        public Employee() : base()
        {
        }

        // Overrides method in base class so that all emails will end with "@testemp.com"
        public override string Email
        {
            get
            {
                return base.Email + "@testemp.com";
            }

            set
            {
                base.Email = value;
            }
        }

    }
}
