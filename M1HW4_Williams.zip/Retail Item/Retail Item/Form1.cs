﻿/**
* 09/9/18
* CSC 253
* Aaron Williams
* This program will display information about three retail items
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Retail_Item
{
    public partial class Form1 : Form
    {
        const int RETAIL_ARRAY_SIZE = 3;
        public Form1()
        {
            InitializeComponent();
        }

        private RetailItem[] assignRetailData()
        {
            // Creates an array to store RetailItem objects
            RetailItem[] retailItemsArray = new RetailItem [RETAIL_ARRAY_SIZE];

            // Creates objects to store in the array
            retailItemsArray[0] = new RetailItem("Jacket", 12, 59.95m);
            retailItemsArray[1] = new RetailItem("Jeans", 40, 34.95m);
            retailItemsArray[2] = new RetailItem("Shirt", 20, 24.95m);
            return retailItemsArray;
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            // Assigns the array created from the assignRetailData method
            RetailItem [] retailItemsArray = assignRetailData();
            // Loop that step through the array to show the properties of each object
            for (int index = 0; index < RETAIL_ARRAY_SIZE; index++)
            {
                retailItemListBox.Items.Add(retailItemsArray[index].Description);
                retailItemListBox.Items.Add(retailItemsArray[index].UnitsOnHand);
                retailItemListBox.Items.Add(retailItemsArray[index].Price);
            }

        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            // Clears the listbox
            retailItemListBox.Items.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Exits program
            this.Close();
        }
    }
}
