﻿namespace Person_and_Customer_Classes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.displayButton = new System.Windows.Forms.Button();
            this.outputGroupBox = new System.Windows.Forms.GroupBox();
            this.mailingListDisplayLabel = new System.Windows.Forms.Label();
            this.customerNumberDisplayLabel = new System.Windows.Forms.Label();
            this.phoneNumberDisplayLabel = new System.Windows.Forms.Label();
            this.addressDisplayLabel = new System.Windows.Forms.Label();
            this.nameDisplayLabel = new System.Windows.Forms.Label();
            this.inputGroupBox = new System.Windows.Forms.GroupBox();
            this.mailingListGroupBox = new System.Windows.Forms.GroupBox();
            this.noMailingListRadioButton = new System.Windows.Forms.RadioButton();
            this.mailingListRadioButton = new System.Windows.Forms.RadioButton();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.customerNumberTextBox = new System.Windows.Forms.TextBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.phoneNumberTextBox = new System.Windows.Forms.TextBox();
            this.addressLabel = new System.Windows.Forms.Label();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.phoneNumberLabel = new System.Windows.Forms.Label();
            this.customerNumberLabel = new System.Windows.Forms.Label();
            this.resestButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.outputGroupBox.SuspendLayout();
            this.inputGroupBox.SuspendLayout();
            this.mailingListGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(87, 270);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(75, 23);
            this.displayButton.TabIndex = 13;
            this.displayButton.Text = "Display";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // outputGroupBox
            // 
            this.outputGroupBox.Controls.Add(this.mailingListDisplayLabel);
            this.outputGroupBox.Controls.Add(this.customerNumberDisplayLabel);
            this.outputGroupBox.Controls.Add(this.phoneNumberDisplayLabel);
            this.outputGroupBox.Controls.Add(this.addressDisplayLabel);
            this.outputGroupBox.Controls.Add(this.nameDisplayLabel);
            this.outputGroupBox.Location = new System.Drawing.Point(519, 12);
            this.outputGroupBox.Name = "outputGroupBox";
            this.outputGroupBox.Size = new System.Drawing.Size(365, 193);
            this.outputGroupBox.TabIndex = 12;
            this.outputGroupBox.TabStop = false;
            this.outputGroupBox.Text = "Output";
            // 
            // mailingListDisplayLabel
            // 
            this.mailingListDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mailingListDisplayLabel.Location = new System.Drawing.Point(19, 160);
            this.mailingListDisplayLabel.Name = "mailingListDisplayLabel";
            this.mailingListDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.mailingListDisplayLabel.TabIndex = 4;
            // 
            // customerNumberDisplayLabel
            // 
            this.customerNumberDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.customerNumberDisplayLabel.Location = new System.Drawing.Point(19, 126);
            this.customerNumberDisplayLabel.Name = "customerNumberDisplayLabel";
            this.customerNumberDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.customerNumberDisplayLabel.TabIndex = 3;
            // 
            // phoneNumberDisplayLabel
            // 
            this.phoneNumberDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.phoneNumberDisplayLabel.Location = new System.Drawing.Point(19, 89);
            this.phoneNumberDisplayLabel.Name = "phoneNumberDisplayLabel";
            this.phoneNumberDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.phoneNumberDisplayLabel.TabIndex = 2;
            // 
            // addressDisplayLabel
            // 
            this.addressDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addressDisplayLabel.Location = new System.Drawing.Point(19, 53);
            this.addressDisplayLabel.Name = "addressDisplayLabel";
            this.addressDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.addressDisplayLabel.TabIndex = 1;
            // 
            // nameDisplayLabel
            // 
            this.nameDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nameDisplayLabel.Location = new System.Drawing.Point(19, 22);
            this.nameDisplayLabel.Name = "nameDisplayLabel";
            this.nameDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.nameDisplayLabel.TabIndex = 0;
            // 
            // inputGroupBox
            // 
            this.inputGroupBox.Controls.Add(this.mailingListGroupBox);
            this.inputGroupBox.Controls.Add(this.nameTextBox);
            this.inputGroupBox.Controls.Add(this.customerNumberTextBox);
            this.inputGroupBox.Controls.Add(this.nameLabel);
            this.inputGroupBox.Controls.Add(this.phoneNumberTextBox);
            this.inputGroupBox.Controls.Add(this.addressLabel);
            this.inputGroupBox.Controls.Add(this.addressTextBox);
            this.inputGroupBox.Controls.Add(this.phoneNumberLabel);
            this.inputGroupBox.Controls.Add(this.customerNumberLabel);
            this.inputGroupBox.Location = new System.Drawing.Point(12, 12);
            this.inputGroupBox.Name = "inputGroupBox";
            this.inputGroupBox.Size = new System.Drawing.Size(485, 242);
            this.inputGroupBox.TabIndex = 11;
            this.inputGroupBox.TabStop = false;
            this.inputGroupBox.Text = "Input";
            // 
            // mailingListGroupBox
            // 
            this.mailingListGroupBox.Controls.Add(this.noMailingListRadioButton);
            this.mailingListGroupBox.Controls.Add(this.mailingListRadioButton);
            this.mailingListGroupBox.Location = new System.Drawing.Point(29, 150);
            this.mailingListGroupBox.Name = "mailingListGroupBox";
            this.mailingListGroupBox.Size = new System.Drawing.Size(433, 72);
            this.mailingListGroupBox.TabIndex = 8;
            this.mailingListGroupBox.TabStop = false;
            this.mailingListGroupBox.Text = "Mailing List";
            // 
            // noMailingListRadioButton
            // 
            this.noMailingListRadioButton.AutoSize = true;
            this.noMailingListRadioButton.Location = new System.Drawing.Point(13, 49);
            this.noMailingListRadioButton.Name = "noMailingListRadioButton";
            this.noMailingListRadioButton.Size = new System.Drawing.Size(159, 17);
            this.noMailingListRadioButton.TabIndex = 1;
            this.noMailingListRadioButton.TabStop = true;
            this.noMailingListRadioButton.Text = "Don\'t Sign up for Mailing List";
            this.noMailingListRadioButton.UseVisualStyleBackColor = true;
            // 
            // mailingListRadioButton
            // 
            this.mailingListRadioButton.AutoSize = true;
            this.mailingListRadioButton.Location = new System.Drawing.Point(13, 19);
            this.mailingListRadioButton.Name = "mailingListRadioButton";
            this.mailingListRadioButton.Size = new System.Drawing.Size(235, 17);
            this.mailingListRadioButton.TabIndex = 0;
            this.mailingListRadioButton.TabStop = true;
            this.mailingListRadioButton.Text = "Agree to Sign up for Mailing List Subscribtion";
            this.mailingListRadioButton.UseVisualStyleBackColor = true;
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(126, 19);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(336, 20);
            this.nameTextBox.TabIndex = 4;
            // 
            // customerNumberTextBox
            // 
            this.customerNumberTextBox.Location = new System.Drawing.Point(126, 124);
            this.customerNumberTextBox.Name = "customerNumberTextBox";
            this.customerNumberTextBox.Size = new System.Drawing.Size(336, 20);
            this.customerNumberTextBox.TabIndex = 7;
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(79, 22);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(41, 13);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Name: ";
            // 
            // phoneNumberTextBox
            // 
            this.phoneNumberTextBox.Location = new System.Drawing.Point(126, 87);
            this.phoneNumberTextBox.Name = "phoneNumberTextBox";
            this.phoneNumberTextBox.Size = new System.Drawing.Size(336, 20);
            this.phoneNumberTextBox.TabIndex = 6;
            // 
            // addressLabel
            // 
            this.addressLabel.AutoSize = true;
            this.addressLabel.Location = new System.Drawing.Point(72, 54);
            this.addressLabel.Name = "addressLabel";
            this.addressLabel.Size = new System.Drawing.Size(48, 13);
            this.addressLabel.TabIndex = 1;
            this.addressLabel.Text = "Address:";
            // 
            // addressTextBox
            // 
            this.addressTextBox.Location = new System.Drawing.Point(126, 51);
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(336, 20);
            this.addressTextBox.TabIndex = 5;
            // 
            // phoneNumberLabel
            // 
            this.phoneNumberLabel.AutoSize = true;
            this.phoneNumberLabel.Location = new System.Drawing.Point(39, 90);
            this.phoneNumberLabel.Name = "phoneNumberLabel";
            this.phoneNumberLabel.Size = new System.Drawing.Size(81, 13);
            this.phoneNumberLabel.TabIndex = 2;
            this.phoneNumberLabel.Text = "Phone Number:";
            // 
            // customerNumberLabel
            // 
            this.customerNumberLabel.AutoSize = true;
            this.customerNumberLabel.Location = new System.Drawing.Point(26, 126);
            this.customerNumberLabel.Name = "customerNumberLabel";
            this.customerNumberLabel.Size = new System.Drawing.Size(94, 13);
            this.customerNumberLabel.TabIndex = 3;
            this.customerNumberLabel.Text = "Customer Number:";
            // 
            // resestButton
            // 
            this.resestButton.Location = new System.Drawing.Point(411, 270);
            this.resestButton.Name = "resestButton";
            this.resestButton.Size = new System.Drawing.Size(75, 23);
            this.resestButton.TabIndex = 14;
            this.resestButton.Text = "Reset";
            this.resestButton.UseVisualStyleBackColor = true;
            this.resestButton.Click += new System.EventHandler(this.resestButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(744, 270);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 15;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(957, 315);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resestButton);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.outputGroupBox);
            this.Controls.Add(this.inputGroupBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.outputGroupBox.ResumeLayout(false);
            this.inputGroupBox.ResumeLayout(false);
            this.inputGroupBox.PerformLayout();
            this.mailingListGroupBox.ResumeLayout(false);
            this.mailingListGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.GroupBox outputGroupBox;
        private System.Windows.Forms.Label customerNumberDisplayLabel;
        private System.Windows.Forms.Label phoneNumberDisplayLabel;
        private System.Windows.Forms.Label addressDisplayLabel;
        private System.Windows.Forms.Label nameDisplayLabel;
        private System.Windows.Forms.GroupBox inputGroupBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox customerNumberTextBox;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.TextBox phoneNumberTextBox;
        private System.Windows.Forms.Label addressLabel;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.Label phoneNumberLabel;
        private System.Windows.Forms.Label customerNumberLabel;
        private System.Windows.Forms.GroupBox mailingListGroupBox;
        private System.Windows.Forms.RadioButton noMailingListRadioButton;
        private System.Windows.Forms.RadioButton mailingListRadioButton;
        private System.Windows.Forms.Label mailingListDisplayLabel;
        private System.Windows.Forms.Button resestButton;
        private System.Windows.Forms.Button exitButton;
    }
}

