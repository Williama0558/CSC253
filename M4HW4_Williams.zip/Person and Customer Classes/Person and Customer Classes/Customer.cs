﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Person_and_Customer_Classes
{
    class Customer : Person
    {
        // Fields for the class
        private string _customerNumber;
        private Boolean _mailingList;


        // No-arg constructor
        public Customer()
        {
            _customerNumber = "";
            _mailingList = false;
        }

        // Constructor with three parameters
        public Customer(string CustomerNumber, Boolean MailingList)
        {
            _customerNumber = CustomerNumber;
            _mailingList = MailingList;
        }

        // Gets information for the customer number variable
        public string CustomerNumber
        {
            get { return _customerNumber; }
            set { _customerNumber = value; }
        }

        // Gets information for the mailing list variable
        public Boolean MailingList
        {
            get { return _mailingList; }
            set { _mailingList = value; }
        }
    }
}
