﻿/**
* 11/11/18
* CSC 253
* Aaron Williams
* This program holds information in a class for customers
* **/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Person_and_Customer_Classes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            // Creates a customer object and initializes some variables
            Customer customer = new Customer();
            customer.Name = nameTextBox.Text;
            customer.Address = addressTextBox.Text;
            customer.PhoneNumber = phoneNumberTextBox.Text;
            customer.CustomerNumber = customerNumberTextBox.Text;

            // Checks to see which radio button was selected
            if (mailingListRadioButton.Checked == true)
            {
                customer.MailingList = true;
            }
            else
            {
                customer.MailingList = false;
            }

            // Display output
            nameDisplayLabel.Text = customer.Name;
            addressDisplayLabel.Text = customer.Address;
            phoneNumberDisplayLabel.Text = customer.PhoneNumber;
            customerNumberDisplayLabel.Text = customer.CustomerNumber;

            // Displays different output depending on the radio button that was selected earlier
            if (customer.MailingList == true)
            {
                mailingListDisplayLabel.Text = "You have signed up for the mailing list";
            }
            else
            {
                mailingListDisplayLabel.Text = "You have chosen to not sign up for the mailing list";
            }

        }

        private void resestButton_Click(object sender, EventArgs e)
        {
            // Resets all the text in the program
            nameTextBox.Text = "";
            addressTextBox.Text = "";
            phoneNumberTextBox.Text = "";
            customerNumberTextBox.Text = "";

            nameDisplayLabel.Text = "";
            addressDisplayLabel.Text = "";
            phoneNumberDisplayLabel.Text = "";
            customerNumberDisplayLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the program
            this.Close();
        }
    }
}
