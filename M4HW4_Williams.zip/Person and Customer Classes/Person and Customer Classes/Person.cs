﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Person_and_Customer_Classes
{
    class Person
    {
        // Fields for the class
        private string _name;
        private string _address;
        private string _phoneNumber;


        // No-arg constructor
        public Person()
        {
            _name = "";
            _address = "";
            _phoneNumber = "";
        }

        // Constructor with three parameters
        public Person(string Name, string Address, string PhoneNumber)
        {
            _name = Name;
            _address = Address;
            _phoneNumber = PhoneNumber;
        }

        // Gets information for the name variable
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        // Gets information for the address variable
        public string Address
        {
            get { return _address; }
            set { _address = value; }
        }

        // Gets information for the phone number variable
        public string PhoneNumber
        {
            get { return _phoneNumber; }
            set { _phoneNumber = value; }
        }
    }
}
