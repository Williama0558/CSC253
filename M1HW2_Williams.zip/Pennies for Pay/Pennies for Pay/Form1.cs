﻿/**
* 08/30/18
* CSC 253
* Aaron Williams
* This programs uses loops to calculate the amount of an employee's pay over how many days are entered in.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pennies_for_Pay
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            int pay = 0;
            int daysWorked;

            // Checks to see if valid user input has been entered. Displays an error message for letters or other invalid input.

            if (int.TryParse(daysWorkedTextBox.Text, out daysWorked))
            {
                if (daysWorked > 0)
                {
                    pay = 1;
                    // loop that runs until the appropriate amount of pay is calculated for the day inputted
                    for (int daysCounter = 1; daysCounter < daysWorked; daysCounter++)
                    {
                        pay = pay + pay;
                    }
                }
                else
                {
                    MessageBox.Show("Invalid amount entered.");
                }
            }
            else
            {
                MessageBox.Show("Invalid amount entered.");
            }

            payLabel.Text = pay.ToString();

        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            // Clears all fields on the form
            daysWorkedTextBox.Text = "";
            payLabel.Text = "";
            daysWorkedTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the program
            this.Close();
        }
    }
}
