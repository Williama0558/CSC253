﻿namespace Pennies_for_Pay
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.daysWorkedTextBox = new System.Windows.Forms.TextBox();
            this.daysLabel = new System.Windows.Forms.Label();
            this.payLabel = new System.Windows.Forms.Label();
            this.payTitleLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // daysWorkedTextBox
            // 
            this.daysWorkedTextBox.Location = new System.Drawing.Point(107, 12);
            this.daysWorkedTextBox.Name = "daysWorkedTextBox";
            this.daysWorkedTextBox.Size = new System.Drawing.Size(100, 20);
            this.daysWorkedTextBox.TabIndex = 0;
            // 
            // daysLabel
            // 
            this.daysLabel.AutoSize = true;
            this.daysLabel.Location = new System.Drawing.Point(26, 15);
            this.daysLabel.Name = "daysLabel";
            this.daysLabel.Size = new System.Drawing.Size(75, 13);
            this.daysLabel.TabIndex = 1;
            this.daysLabel.Text = "Days Worked:";
            // 
            // payLabel
            // 
            this.payLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.payLabel.Location = new System.Drawing.Point(107, 48);
            this.payLabel.Name = "payLabel";
            this.payLabel.Size = new System.Drawing.Size(100, 23);
            this.payLabel.TabIndex = 2;
            // 
            // payTitleLabel
            // 
            this.payTitleLabel.AutoSize = true;
            this.payTitleLabel.Location = new System.Drawing.Point(73, 49);
            this.payTitleLabel.Name = "payTitleLabel";
            this.payTitleLabel.Size = new System.Drawing.Size(28, 13);
            this.payTitleLabel.TabIndex = 3;
            this.payTitleLabel.Text = "Pay:";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(13, 90);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 4;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(107, 89);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 23);
            this.resetButton.TabIndex = 5;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(197, 89);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 126);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.payTitleLabel);
            this.Controls.Add(this.payLabel);
            this.Controls.Add(this.daysLabel);
            this.Controls.Add(this.daysWorkedTextBox);
            this.Name = "Form1";
            this.Text = "Pennies for Pay";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox daysWorkedTextBox;
        private System.Windows.Forms.Label daysLabel;
        private System.Windows.Forms.Label payLabel;
        private System.Windows.Forms.Label payTitleLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button exitButton;
    }
}

