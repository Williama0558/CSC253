﻿/**
* 09/30/2018
* CSC 253
* Group 2

* Group Members: Aaron Williams, Nicholas Allen
* This program is a dungeon crawl game where the player can get loot, fight monsters, and explore a dungeon.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Catacombs_of_Bool
{
    class Program
    {
        // Bool variable that keeps the program running
        public static bool runProgram = true;
        // Initialization of room array to allow movement and arrays that will be used in future iterations of the program
        public static string[,] roomsArray = { { "Entrance", "North Hallway", "Empty Room" },
                                               { "Treasure Stash", "Central Hallway", "Armory" },
                                               {  "Boss Room", "South Hallway", "Emergency Exit"} };

        static void Main(string[] args)
        {
            string[] potionsArray = { "Health potion", "Greater Health Potion" };
            string[] treasuresArray = { };

            List<string> itemList = new List<string>() { "Bools' Mittens", "Iron Chestpiece", "Iron Boots", "Iron Buckler" };
            List<string> mobList = new List<string>() { "Dire Spider", "Servant of Bool", "GIANT Rat", "Animated Armor", "Goblin"};

            // Variable that keeps track of where the player is.
            string playerPosition = roomsArray[0, 0];


            while (runProgram == true)
            {
                Console.Write("Welcome to Catacombs of Bool, a text-based dungeon crawl made with the Visual Studio console.");
                Console.Write("This first iteration of the game tests movement using arrays as well as list and array creation.\n\nPlease type in 'Start'" +
                              " to start the game: ");
                string startGame = Console.ReadLine().ToUpper();

                if (startGame == "START")
                {
                    Console.Write("\nYou move into the Entrance of the dungeon.\n");
                    moveToEntrance(playerPosition, roomsArray);
                }
                else
                {
                    Console.Write(startGame + " is not a valid option, please try again.\n\n");
                    Main(args);
                }
            }


        }

        private static void selectOption(string userChoice)
        {
            // Method that holds options that don't control the player's movement.
            // Picks an option based on user input from other methods.
            if (userChoice == "HELP")
            {
                displayHelp();
            }
            else if (userChoice == "WEAPONS")
            {
                displayWeapons();
            }
            else if (userChoice == "END")
            {
                endGame();
            }
            else if (userChoice == "ROOM")
            {
                displayRooms();
            }
            else
            {
                Console.Write(userChoice + " is not a valid option.\n\n");
            }
        }

        private static void displayHelp()
        {
            // Method that will display a list of commands to the user.
            Console.Write("\nType 'end' to bring up the option to quit the game.\n");
            Console.Write("Type 'weapons' to display the weapons array.\n");
            Console.Write("Type 'room' to display the rooms array\n");
        }

        private static void displayWeapons()
        {
            // Method that displays and sorts an array of weapons in alphabetical order.
            string[] weaponsArray = { "Sword", "Axe", "Spear", "Mace" };
            Array.Sort(weaponsArray);
            foreach (string element in weaponsArray)
            {
                Console.Write(element + " ");
            }
        }

        private static void displayRooms()
        {
            // Method that will display all of the room names in the roomsArray.
            foreach (string element in roomsArray)
            {
                Console.Write(element + ", ");
            }
        }

        private static void endGame()
        {
            // Method that will allow the user to end the game/program.
            Console.Write("Press Y if you would like to end the game: ");
            string userInput = Console.ReadLine().ToUpper();

            if (userInput == "Y")
            {
                Environment.Exit(0);
                runProgram = false;
            }
            else
            {
                Console.Write("Invalid input, resuming game...\n");
            }
        }

        private static void moveToEntrance(string playerPosition, string[,] roomsArray)
        {
            // Method that describes one of the rooms the player can enter.

            // Loop that will keep the player in the room until it is updated by the player choosing to leave.
            while (playerPosition == roomsArray[0, 0])
            {
                Console.Write("\nFrom here you can see the North Hallway to the east(E)");
                Console.Write("\nYou can also write 'Help' to bring up a list of commands.");
                Console.Write("\nWhat would you like to do: ");
                string userChoice = Console.ReadLine().ToUpper();

                // If-else tree that controls what the user can enter as input.
                if (userChoice == "E")
                {
                    Console.Write("You move towards the east\n");
                    Console.Write("You have arrived in the North Hallway of the Catacombs\n\n");
                    playerPosition = roomsArray[0, 1];
                    moveToNorthHall(playerPosition, roomsArray);

                }
                else
                {
                    selectOption(userChoice);
                }
            }
        }

        private static void moveToNorthHall(string playerPosition, string[,] roomsArray)
        {
            // Method that describes one of the rooms the player can enter.

            // Loop that will keep the player in the room until it is updated by the player choosing to leave.
            while (playerPosition == roomsArray[0, 1])
            {
                Console.Write("\nFrom here you can see the Entrance to the west(W), an empty room to the east(E), and the Central Hallway to the south(S)");
                Console.Write("\nYou can also write 'Help' to bring up a list of commands.");
                Console.Write("\nWhat would you like to do: ");
                string userChoice = Console.ReadLine().ToUpper();

                if (userChoice == "E")
                {
                    Console.Write("You move towards the east\n");
                    Console.Write("Congratulations! You have entered an empty room.\n\n");
                    playerPosition = roomsArray[0, 2];
                    moveToEmptyRoom(playerPosition, roomsArray);

                }
                else if (userChoice == "W")
                {
                    Console.Write("You move towards the west\n");
                    Console.Write("You have arrived at the Entrance of the Catacombs.\n\n");
                    playerPosition = roomsArray[0, 0];
                    moveToEntrance(playerPosition, roomsArray);
                }
                else if (userChoice == "S")
                {
                    Console.Write("You move towards the south\n");
                    Console.Write("You have arrived in the Central Hallway of the Catacombs.\n\n");
                    playerPosition = roomsArray[1, 1];
                    moveToCentralHall(playerPosition, roomsArray);
                }
                else
                {
                    selectOption(userChoice);
                }
            }
        }

        private static void moveToEmptyRoom(string playerPosition, string[,] roomsArray)
        {
            // Method that describes one of the rooms the player can enter.

            // Loop that will keep the player in the room until it is updated by the player choosing to leave.
            while (playerPosition == roomsArray[0, 2])
            {
                Console.Write("\nFrom here you can see the North Hallway to the west(W)");
                Console.Write("\nYou can also write 'Help' to bring up a list of commands.");
                Console.Write("\nWhat would you like to do: ");
                string userChoice = Console.ReadLine().ToUpper();

                if (userChoice == "W")
                {
                    Console.Write("You move towards the west\n");
                    Console.Write("You have arrived in the North Hallway of the Catacombs\n\n");
                    playerPosition = roomsArray[0, 1];
                    moveToNorthHall(playerPosition, roomsArray);

                }
                else
                {
                    selectOption(userChoice);
                }
            }
        }


        private static void moveToCentralHall(string playerPosition, string[,] roomsArray)
        {
            // Method that describes one of the rooms the player can enter.

            // Loop that will keep the player in the room until it is updated by the player choosing to leave.
            while (playerPosition == roomsArray[1, 1])
            {
                Console.Write("\nFrom here you can see the Treasure Stash to the west(W), The Armory to the east(E), the South Hallway to the south(S), and the"
                              + " North Hallway to the north(N);");
                Console.Write("\nYou can also write 'Help' to bring up a list of commands.");
                Console.Write("\nWhat would you like to do: ");
                string userChoice = Console.ReadLine().ToUpper();

                
                if (userChoice == "E")
                {
                    Console.Write("You move towards the east\n");
                    Console.Write("You have arrived at the Armory.\n\n");
                    playerPosition = roomsArray[1, 2];
                    moveToArmory(playerPosition, roomsArray);

                }
                else if (userChoice == "W")
                {
                    Console.Write("You move towards the west\n");
                    Console.Write("You have arrived at Treasure Stash.\n\n");
                    playerPosition = roomsArray[1, 0];
                    moveToStash(playerPosition, roomsArray);
                }
                else if (userChoice == "S")
                {
                    Console.Write("You move towards the south\n");
                    Console.Write("You have arrived in the South Hallway of the Catacombs.\n\n");
                    playerPosition = roomsArray[2, 1];
                    moveToSouthHall(playerPosition, roomsArray);
                }
                else if (userChoice == "N")
                {
                    Console.Write("You move towards the north\n");
                    Console.Write("You have arrived in the North Hallway of the Catacombs.\n\n");
                    playerPosition = roomsArray[0, 1];
                    moveToNorthHall(playerPosition, roomsArray);
                }
                else
                {
                    selectOption(userChoice);
                }
            }
        }

        private static void moveToStash(string playerPosition, string[,] roomsArray)
        {
            // Method that describes one of the rooms the player can enter.

            // Loop that will keep the player in the room until it is updated by the player choosing to leave.
            while (playerPosition == roomsArray[1, 0])
            {
                Console.Write("\nFrom here you can see the Central Hall to the east(E).");
                Console.Write("\nYou can also write 'Help' to bring up a list of commands.");
                Console.Write("\nWhat would you like to do: ");
                string userChoice = Console.ReadLine().ToUpper();


                if (userChoice == "E")
                {
                    Console.Write("You move towards the east\n");
                    Console.Write("You have arrived at the Central Hallway.\n\n");
                    playerPosition = roomsArray[1, 1];
                    moveToCentralHall(playerPosition, roomsArray);

                }
                else
                {
                    selectOption(userChoice);
                }
            }
        }

        private static void moveToArmory(string playerPosition, string[,] roomsArray)
        {
            // Method that describes one of the rooms the player can enter.

            // Loop that will keep the player in the room until it is updated by the player choosing to leave.
            while (playerPosition == roomsArray[1, 2])
            {
                Console.Write("\nFrom here you can see the Central Hall to the west(W).");
                Console.Write("\nYou can also write 'Help' to bring up a list of commands.");
                Console.Write("\nWhat would you like to do: ");
                string userChoice = Console.ReadLine().ToUpper();


                if (userChoice == "W")
                {
                    Console.Write("You move towards the west\n");
                    Console.Write("You have arrived at the Central Hallway.\n\n");
                    playerPosition = roomsArray[1, 1];
                    moveToCentralHall(playerPosition, roomsArray);

                }
                else
                {
                    selectOption(userChoice);
                }
            }
        }

        private static void moveToSouthHall(string playerPosition, string[,] roomsArray)
        {
            // Method that describes one of the rooms the player can enter.

            // Loop that will keep the player in the room until it is updated by the player choosing to leave.
            while (playerPosition == roomsArray[2, 1])
            {
                Console.Write("\nFrom here you can see the Boss Room to the west(W), The Exit to the east(E), and the Central Hallway to the north(N);");
                Console.Write("\nYou can also write 'Help' to bring up a list of commands.");
                Console.Write("\nWhat would you like to do: ");
                string userChoice = Console.ReadLine().ToUpper();


                if (userChoice == "E")
                {
                    Console.Write("You move towards the east\n");
                    Console.Write("You have arrived at the Exit.\n\n");
                    playerPosition = roomsArray[2, 2];
                    moveToExit(playerPosition, roomsArray);

                }
                else if (userChoice == "W")
                {
                    Console.Write("You move towards the west\n");
                    Console.Write("You have arrived at Boss Room.\n\n");
                    playerPosition = roomsArray[2, 0];
                    moveToBossRoom(playerPosition, roomsArray);
                }
                else if (userChoice == "N")
                {
                    Console.Write("You move towards the north\n");
                    Console.Write("You have arrived in the Central Hallway of the Catacombs.\n\n");
                    playerPosition = roomsArray[1, 1];
                    moveToCentralHall(playerPosition, roomsArray);
                }
                else
                {
                    selectOption(userChoice);
                }
            }
        }

        private static void moveToBossRoom(string playerPosition, string[,] roomsArray)
        {
            // Method that describes one of the rooms the player can enter.

            // Loop that will keep the player in the room until it is updated by the player choosing to leave.
            while (playerPosition == roomsArray[2, 0])
            {
                Console.Write("\nFrom here you can see the South Hall to the east(E).");
                Console.Write("\nYou can also write 'Help' to bring up a list of commands.");
                Console.Write("\nWhat would you like to do: ");
                string userChoice = Console.ReadLine().ToUpper();


                if (userChoice == "E")
                {
                    Console.Write("You move towards the east\n");
                    Console.Write("You have arrived at the South Hallway.\n\n");
                    playerPosition = roomsArray[2, 1];
                    moveToSouthHall(playerPosition, roomsArray);

                }
                else
                {
                    selectOption(userChoice);
                }
            }
        }

        private static void moveToExit(string playerPosition, string[,] roomsArray)
        {
            // Method that describes one of the rooms the player can enter.

            // Loop that will keep the player in the room until it is updated by the player choosing to leave.
            while (playerPosition == roomsArray[2, 2])
            {
                Console.Write("\nFrom here you can see the South Hall to the west(W).");
                Console.Write("\nYou can also write 'Help' to bring up a list of commands.");
                Console.Write("\nWhat would you like to do: ");
                string userChoice = Console.ReadLine().ToUpper();


                if (userChoice == "W")
                {
                    Console.Write("You move towards the west\n");
                    Console.Write("You have arrived at the South Hallway.\n\n");
                    playerPosition = roomsArray[2, 1];
                    moveToSouthHall(playerPosition, roomsArray);

                }
                else
                {
                    selectOption(userChoice);
                }
            }
        }
    }
}