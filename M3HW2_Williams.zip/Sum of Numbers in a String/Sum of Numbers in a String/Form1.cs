﻿/**
* 10/12/18
* CSC 253
* Aaron Williams
* This program calculates the sum of numbers entered in as a string
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sum_of_Numbers_in_a_String
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            int total = 0;
            string userString = numbersTextBox.Text;
            // Splits characters using commas
            char[] delim = { ',' };
            string[] userStringArray = userString.Split(delim);
            for (int index = 0; index < userStringArray.Length; index++)
            {
                int userInteger = int.Parse(userStringArray[index]);
                total += userInteger;
            }
            totalLabel.Text = total.ToString();


        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            numbersTextBox.Text = "";
            totalLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
