﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShiftSupervisorClass
{
    class ShiftSupervisor : Employee
    {
        // Fields for the class
        private decimal _salary;
        private decimal _bonus;


        // No-arg constructor
        public ShiftSupervisor()
        {
            _salary = 0.0m;
            _bonus = 0.0m;
        }

        // Constructor with two parameters
        public ShiftSupervisor(decimal salary, decimal bonus)
        {
            _salary = salary;
            _bonus = bonus;
        }

        // Gets information for the shift number variable
        public decimal salary
        {
            get { return _salary; }
            set { _salary = value; }
        }

        // Gets information for the pay rate variable
        public decimal bonus
        {
            get { return _bonus; }
            set { _bonus = value; }
        }
    }
}
