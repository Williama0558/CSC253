﻿/**
* 11/4/18
* CSC 253
* Aaron Williams
* This program holds information in a class for supervisors
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShiftSupervisorClass
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            // Variables that will be passed into classes
            decimal salary = 0.0m;
            decimal bonus = 0.0m;

            // Creates a production worker object and initializes some variables
            ShiftSupervisor supervisor = new ShiftSupervisor();
            supervisor.Name = nameTextBox.Text;
            supervisor.Number = numberTextBox.Text;

            // Checks to make sure proper input is entered in the salary field.
            if (decimal.TryParse(salaryTextBox.Text, out salary))
            {
                supervisor.salary = decimal.Parse(salaryTextBox.Text);
            }
            else
            {
                MessageBox.Show("Invalid input for salary entered");
            }

            // Checks to make sure proper input is entered in the bonus field.
            if (decimal.TryParse(productionBonusTextBox.Text, out bonus))
            {
                supervisor.bonus = decimal.Parse(productionBonusTextBox.Text);
            }
            else
            {
                MessageBox.Show("Invalid input for bonus entered");
            }

            // Displays output
            nameDisplayLabel.Text = supervisor.Name;
            numberDisplayLabel.Text = supervisor.Number;
            salaryDisplayLabel.Text = supervisor.salary.ToString();
            bonusDisplayLabel.Text = supervisor.bonus.ToString();
        }
    }
}
