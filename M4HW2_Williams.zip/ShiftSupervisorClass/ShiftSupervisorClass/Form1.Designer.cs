﻿namespace ShiftSupervisorClass
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.displayButton = new System.Windows.Forms.Button();
            this.outputGroupBox = new System.Windows.Forms.GroupBox();
            this.bonusDisplayLabel = new System.Windows.Forms.Label();
            this.salaryDisplayLabel = new System.Windows.Forms.Label();
            this.numberDisplayLabel = new System.Windows.Forms.Label();
            this.nameDisplayLabel = new System.Windows.Forms.Label();
            this.inputGroupBox = new System.Windows.Forms.GroupBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.productionBonusTextBox = new System.Windows.Forms.TextBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.salaryTextBox = new System.Windows.Forms.TextBox();
            this.numberLabel = new System.Windows.Forms.Label();
            this.numberTextBox = new System.Windows.Forms.TextBox();
            this.salaryLabel = new System.Windows.Forms.Label();
            this.productionBonusLabel = new System.Windows.Forms.Label();
            this.outputGroupBox.SuspendLayout();
            this.inputGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(138, 197);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(75, 23);
            this.displayButton.TabIndex = 13;
            this.displayButton.Text = "Display";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // outputGroupBox
            // 
            this.outputGroupBox.Controls.Add(this.bonusDisplayLabel);
            this.outputGroupBox.Controls.Add(this.salaryDisplayLabel);
            this.outputGroupBox.Controls.Add(this.numberDisplayLabel);
            this.outputGroupBox.Controls.Add(this.nameDisplayLabel);
            this.outputGroupBox.Location = new System.Drawing.Point(512, 12);
            this.outputGroupBox.Name = "outputGroupBox";
            this.outputGroupBox.Size = new System.Drawing.Size(365, 164);
            this.outputGroupBox.TabIndex = 12;
            this.outputGroupBox.TabStop = false;
            this.outputGroupBox.Text = "Output";
            // 
            // bonusDisplayLabel
            // 
            this.bonusDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bonusDisplayLabel.Location = new System.Drawing.Point(19, 126);
            this.bonusDisplayLabel.Name = "bonusDisplayLabel";
            this.bonusDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.bonusDisplayLabel.TabIndex = 3;
            // 
            // salaryDisplayLabel
            // 
            this.salaryDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.salaryDisplayLabel.Location = new System.Drawing.Point(19, 89);
            this.salaryDisplayLabel.Name = "salaryDisplayLabel";
            this.salaryDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.salaryDisplayLabel.TabIndex = 2;
            // 
            // numberDisplayLabel
            // 
            this.numberDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberDisplayLabel.Location = new System.Drawing.Point(19, 53);
            this.numberDisplayLabel.Name = "numberDisplayLabel";
            this.numberDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.numberDisplayLabel.TabIndex = 1;
            // 
            // nameDisplayLabel
            // 
            this.nameDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nameDisplayLabel.Location = new System.Drawing.Point(19, 22);
            this.nameDisplayLabel.Name = "nameDisplayLabel";
            this.nameDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.nameDisplayLabel.TabIndex = 0;
            // 
            // inputGroupBox
            // 
            this.inputGroupBox.Controls.Add(this.nameTextBox);
            this.inputGroupBox.Controls.Add(this.productionBonusTextBox);
            this.inputGroupBox.Controls.Add(this.nameLabel);
            this.inputGroupBox.Controls.Add(this.salaryTextBox);
            this.inputGroupBox.Controls.Add(this.numberLabel);
            this.inputGroupBox.Controls.Add(this.numberTextBox);
            this.inputGroupBox.Controls.Add(this.salaryLabel);
            this.inputGroupBox.Controls.Add(this.productionBonusLabel);
            this.inputGroupBox.Location = new System.Drawing.Point(12, 12);
            this.inputGroupBox.Name = "inputGroupBox";
            this.inputGroupBox.Size = new System.Drawing.Size(485, 164);
            this.inputGroupBox.TabIndex = 11;
            this.inputGroupBox.TabStop = false;
            this.inputGroupBox.Text = "Input";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(126, 19);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(336, 20);
            this.nameTextBox.TabIndex = 4;
            // 
            // productionBonusTextBox
            // 
            this.productionBonusTextBox.Location = new System.Drawing.Point(126, 124);
            this.productionBonusTextBox.Name = "productionBonusTextBox";
            this.productionBonusTextBox.Size = new System.Drawing.Size(336, 20);
            this.productionBonusTextBox.TabIndex = 7;
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(79, 22);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(41, 13);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Name: ";
            // 
            // salaryTextBox
            // 
            this.salaryTextBox.Location = new System.Drawing.Point(126, 87);
            this.salaryTextBox.Name = "salaryTextBox";
            this.salaryTextBox.Size = new System.Drawing.Size(336, 20);
            this.salaryTextBox.TabIndex = 6;
            // 
            // numberLabel
            // 
            this.numberLabel.AutoSize = true;
            this.numberLabel.Location = new System.Drawing.Point(21, 54);
            this.numberLabel.Name = "numberLabel";
            this.numberLabel.Size = new System.Drawing.Size(99, 13);
            this.numberLabel.TabIndex = 1;
            this.numberLabel.Text = "Employee Number: ";
            // 
            // numberTextBox
            // 
            this.numberTextBox.Location = new System.Drawing.Point(126, 51);
            this.numberTextBox.Name = "numberTextBox";
            this.numberTextBox.Size = new System.Drawing.Size(336, 20);
            this.numberTextBox.TabIndex = 5;
            // 
            // salaryLabel
            // 
            this.salaryLabel.AutoSize = true;
            this.salaryLabel.Location = new System.Drawing.Point(45, 90);
            this.salaryLabel.Name = "salaryLabel";
            this.salaryLabel.Size = new System.Drawing.Size(75, 13);
            this.salaryLabel.TabIndex = 2;
            this.salaryLabel.Text = "Annual Salary:";
            // 
            // productionBonusLabel
            // 
            this.productionBonusLabel.AutoSize = true;
            this.productionBonusLabel.Location = new System.Drawing.Point(30, 127);
            this.productionBonusLabel.Name = "productionBonusLabel";
            this.productionBonusLabel.Size = new System.Drawing.Size(94, 13);
            this.productionBonusLabel.TabIndex = 3;
            this.productionBonusLabel.Text = "Production Bonus:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(902, 241);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.outputGroupBox);
            this.Controls.Add(this.inputGroupBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.outputGroupBox.ResumeLayout(false);
            this.inputGroupBox.ResumeLayout(false);
            this.inputGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.GroupBox outputGroupBox;
        private System.Windows.Forms.Label bonusDisplayLabel;
        private System.Windows.Forms.Label salaryDisplayLabel;
        private System.Windows.Forms.Label numberDisplayLabel;
        private System.Windows.Forms.Label nameDisplayLabel;
        private System.Windows.Forms.GroupBox inputGroupBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox productionBonusTextBox;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.TextBox salaryTextBox;
        private System.Windows.Forms.Label numberLabel;
        private System.Windows.Forms.TextBox numberTextBox;
        private System.Windows.Forms.Label salaryLabel;
        private System.Windows.Forms.Label productionBonusLabel;
    }
}

