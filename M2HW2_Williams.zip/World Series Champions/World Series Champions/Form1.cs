﻿/**
* 09/30/18
* CSC 253
* Aaron Williams
* This program shows every Baseball team that has ever won the World Series and allows the use to click a name to see how many times they've won
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace World_Series_Champions
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Size declarator for the teams array
            const int TEAMS_SIZE = 29;
            int teamsIndex = 0;
            // Opens and reads from a file named 'Teams.txt'
            StreamReader teams = new StreamReader("Teams.txt");
            // Creates a new string array named teamsArray
            string[] teamsArray = new string[TEAMS_SIZE];

            // Reads through each line in the opened file and assigns it to an element in the teamsArray
            while(!teams.EndOfStream)
            {
                string teamLine = teams.ReadLine();
                teamsArray[teamsIndex] += teamLine;
                teamsIndex++;
            }
            // Closes the file being read
            teams.Close();

            // Adds the teams read from the file to the listbox
            for (int teamsArrayIndex = 0; teamsArrayIndex < teamsArray.Length; teamsArrayIndex++)
            {
                teamsListBox.Items.Add(teamsArray[teamsArrayIndex]);
            }
        }

        private void confirmButton_Click(object sender, EventArgs e)
        {
            const int VICTORIES_SIZE = 108;
            int victoriesIndex = 0;
            StreamReader victories = new StreamReader("WorldSeriesWinners.txt");
            string[] victoriesArray = new string[VICTORIES_SIZE];
            int victoriesAccumulator = 0;
            while (!victories.EndOfStream)
            {
                string victoryLine = victories.ReadLine();
                victoriesArray[victoriesIndex] += victoryLine;
                victoriesIndex++;
            }

            // Checks to see how many times a team has won the world series by comparing the two arrays
            if (teamsListBox.SelectedIndex != -1)
            {
                string selectedTeam = teamsListBox.SelectedItem.ToString();
                for (int victoriesArrayIndex = 0; victoriesArrayIndex < victoriesArray.Length; victoriesArrayIndex++)
                {
                    if (victoriesArray[victoriesArrayIndex] == selectedTeam)
                    {
                        victoriesAccumulator ++;
                    }
                }

                MessageBox.Show("The " + selectedTeam + " have won the World Series " + victoriesAccumulator + " times in total!");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes program.
            this.Close();
        }
    }
}
