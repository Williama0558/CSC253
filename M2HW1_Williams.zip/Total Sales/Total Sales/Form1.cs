﻿/**
* 09/30/18
* CSC 253
* Aaron Williams
* This program reads sales from a text file, displays them in a listbox, and then totals them
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Total_Sales
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            // Prevents the user from showing multiple instances of the sales array in the listbox

            salesListBox.Items.Clear();
            // Size declarator of the sales array
            const int SIZE = 7;
            // Creates a double array named sales
            double[] sales = new double[SIZE];
            StreamReader inputFile;
            // index of sales array used to step through elements.
            int index = 0;
            double arrayTotal = 0;
            // Opens text file named 'Sales.txt' to read from
            inputFile = File.OpenText("Sales.txt");

            // While loop that reads all of lines from the opened text file.
            while (!inputFile.EndOfStream)
            {
                sales[index] = double.Parse(inputFile.ReadLine());
                index++;
            }
            // Closes the file being read
            inputFile.Close();
            foreach (double value in sales)
            {
                salesListBox.Items.Add(value);
            }
            
            // For loop that adds all of the sales together
            for (int arrayIndex = 0; arrayIndex < sales.Length; arrayIndex++)
            {
                arrayTotal += sales[arrayIndex];
            }

            // Displays total.
            totalDisplayLabel.Text = arrayTotal.ToString();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the program
            this.Close();
        }
    }
}
