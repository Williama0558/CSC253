﻿namespace Name_Search
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.boyNamesGroupBox = new System.Windows.Forms.GroupBox();
            this.boyNameSearchButton = new System.Windows.Forms.Button();
            this.boyNameLabel = new System.Windows.Forms.Label();
            this.boyNameTextBox = new System.Windows.Forms.TextBox();
            this.girlNamesGroupBox = new System.Windows.Forms.GroupBox();
            this.girlNameSearchButton = new System.Windows.Forms.Button();
            this.girlNamesLabel = new System.Windows.Forms.Label();
            this.girlNamesTextBox = new System.Windows.Forms.TextBox();
            this.unisexNamesTextBox = new System.Windows.Forms.GroupBox();
            this.unisexNameSearchButton = new System.Windows.Forms.Button();
            this.unisexNameLabel = new System.Windows.Forms.Label();
            this.unisexNameTextBox = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.boyNamesGroupBox.SuspendLayout();
            this.girlNamesGroupBox.SuspendLayout();
            this.unisexNamesTextBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // boyNamesGroupBox
            // 
            this.boyNamesGroupBox.Controls.Add(this.boyNameSearchButton);
            this.boyNamesGroupBox.Controls.Add(this.boyNameLabel);
            this.boyNamesGroupBox.Controls.Add(this.boyNameTextBox);
            this.boyNamesGroupBox.Location = new System.Drawing.Point(13, 13);
            this.boyNamesGroupBox.Name = "boyNamesGroupBox";
            this.boyNamesGroupBox.Size = new System.Drawing.Size(186, 105);
            this.boyNamesGroupBox.TabIndex = 0;
            this.boyNamesGroupBox.TabStop = false;
            this.boyNamesGroupBox.Text = "Boy Names";
            // 
            // boyNameSearchButton
            // 
            this.boyNameSearchButton.Location = new System.Drawing.Point(52, 65);
            this.boyNameSearchButton.Name = "boyNameSearchButton";
            this.boyNameSearchButton.Size = new System.Drawing.Size(75, 23);
            this.boyNameSearchButton.TabIndex = 2;
            this.boyNameSearchButton.Text = "Search";
            this.boyNameSearchButton.UseVisualStyleBackColor = true;
            this.boyNameSearchButton.Click += new System.EventHandler(this.boyNameSearchButton_Click);
            // 
            // boyNameLabel
            // 
            this.boyNameLabel.AutoSize = true;
            this.boyNameLabel.Location = new System.Drawing.Point(6, 32);
            this.boyNameLabel.Name = "boyNameLabel";
            this.boyNameLabel.Size = new System.Drawing.Size(66, 13);
            this.boyNameLabel.TabIndex = 1;
            this.boyNameLabel.Text = "Boy\'s Name:";
            // 
            // boyNameTextBox
            // 
            this.boyNameTextBox.Location = new System.Drawing.Point(78, 29);
            this.boyNameTextBox.Name = "boyNameTextBox";
            this.boyNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.boyNameTextBox.TabIndex = 0;
            // 
            // girlNamesGroupBox
            // 
            this.girlNamesGroupBox.Controls.Add(this.girlNameSearchButton);
            this.girlNamesGroupBox.Controls.Add(this.girlNamesLabel);
            this.girlNamesGroupBox.Controls.Add(this.girlNamesTextBox);
            this.girlNamesGroupBox.Location = new System.Drawing.Point(215, 13);
            this.girlNamesGroupBox.Name = "girlNamesGroupBox";
            this.girlNamesGroupBox.Size = new System.Drawing.Size(186, 105);
            this.girlNamesGroupBox.TabIndex = 1;
            this.girlNamesGroupBox.TabStop = false;
            this.girlNamesGroupBox.Text = "Girl Names";
            // 
            // girlNameSearchButton
            // 
            this.girlNameSearchButton.Location = new System.Drawing.Point(52, 65);
            this.girlNameSearchButton.Name = "girlNameSearchButton";
            this.girlNameSearchButton.Size = new System.Drawing.Size(75, 23);
            this.girlNameSearchButton.TabIndex = 2;
            this.girlNameSearchButton.Text = "Search";
            this.girlNameSearchButton.UseVisualStyleBackColor = true;
            this.girlNameSearchButton.Click += new System.EventHandler(this.girlNameSearchButton_Click);
            // 
            // girlNamesLabel
            // 
            this.girlNamesLabel.AutoSize = true;
            this.girlNamesLabel.Location = new System.Drawing.Point(6, 32);
            this.girlNamesLabel.Name = "girlNamesLabel";
            this.girlNamesLabel.Size = new System.Drawing.Size(63, 13);
            this.girlNamesLabel.TabIndex = 1;
            this.girlNamesLabel.Text = "Girl\'s Name:";
            // 
            // girlNamesTextBox
            // 
            this.girlNamesTextBox.Location = new System.Drawing.Point(78, 29);
            this.girlNamesTextBox.Name = "girlNamesTextBox";
            this.girlNamesTextBox.Size = new System.Drawing.Size(100, 20);
            this.girlNamesTextBox.TabIndex = 0;
            // 
            // unisexNamesTextBox
            // 
            this.unisexNamesTextBox.Controls.Add(this.unisexNameSearchButton);
            this.unisexNamesTextBox.Controls.Add(this.unisexNameLabel);
            this.unisexNamesTextBox.Controls.Add(this.unisexNameTextBox);
            this.unisexNamesTextBox.Location = new System.Drawing.Point(422, 13);
            this.unisexNamesTextBox.Name = "unisexNamesTextBox";
            this.unisexNamesTextBox.Size = new System.Drawing.Size(186, 105);
            this.unisexNamesTextBox.TabIndex = 3;
            this.unisexNamesTextBox.TabStop = false;
            this.unisexNamesTextBox.Text = "Unisex Names";
            // 
            // unisexNameSearchButton
            // 
            this.unisexNameSearchButton.Location = new System.Drawing.Point(52, 65);
            this.unisexNameSearchButton.Name = "unisexNameSearchButton";
            this.unisexNameSearchButton.Size = new System.Drawing.Size(75, 23);
            this.unisexNameSearchButton.TabIndex = 2;
            this.unisexNameSearchButton.Text = "Search";
            this.unisexNameSearchButton.UseVisualStyleBackColor = true;
            this.unisexNameSearchButton.Click += new System.EventHandler(this.unisexNameSearchButton_Click);
            // 
            // unisexNameLabel
            // 
            this.unisexNameLabel.AutoSize = true;
            this.unisexNameLabel.Location = new System.Drawing.Point(6, 32);
            this.unisexNameLabel.Name = "unisexNameLabel";
            this.unisexNameLabel.Size = new System.Drawing.Size(73, 13);
            this.unisexNameLabel.TabIndex = 1;
            this.unisexNameLabel.Text = "Unisex Name:";
            // 
            // unisexNameTextBox
            // 
            this.unisexNameTextBox.Location = new System.Drawing.Point(80, 29);
            this.unisexNameTextBox.Name = "unisexNameTextBox";
            this.unisexNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.unisexNameTextBox.TabIndex = 0;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(267, 138);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 173);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.unisexNamesTextBox);
            this.Controls.Add(this.girlNamesGroupBox);
            this.Controls.Add(this.boyNamesGroupBox);
            this.Name = "Form1";
            this.Text = "Name Search";
            this.boyNamesGroupBox.ResumeLayout(false);
            this.boyNamesGroupBox.PerformLayout();
            this.girlNamesGroupBox.ResumeLayout(false);
            this.girlNamesGroupBox.PerformLayout();
            this.unisexNamesTextBox.ResumeLayout(false);
            this.unisexNamesTextBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox boyNamesGroupBox;
        private System.Windows.Forms.Button boyNameSearchButton;
        private System.Windows.Forms.Label boyNameLabel;
        private System.Windows.Forms.TextBox boyNameTextBox;
        private System.Windows.Forms.GroupBox girlNamesGroupBox;
        private System.Windows.Forms.Button girlNameSearchButton;
        private System.Windows.Forms.Label girlNamesLabel;
        private System.Windows.Forms.TextBox girlNamesTextBox;
        private System.Windows.Forms.GroupBox unisexNamesTextBox;
        private System.Windows.Forms.Button unisexNameSearchButton;
        private System.Windows.Forms.Label unisexNameLabel;
        private System.Windows.Forms.TextBox unisexNameTextBox;
        private System.Windows.Forms.Button exitButton;
    }
}

