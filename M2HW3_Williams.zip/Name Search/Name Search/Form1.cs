﻿/**
* 09/30/18
* CSC 253
* Aaron Williams
* This program lets the user enter in a name and then tells them if it was one of the most popular between 2000 and 2009
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace Name_Search
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private static StreamReader readBoyNamesFile()
        {
            // Opens a text file named "BoyNames.txt" and reads from it.
            StreamReader boyNames = new StreamReader("BoyNames.txt");
            return boyNames;
        }

        private static StreamReader readGirlNamesFile()
        {
            // Opens a text file named "GirlNames.txt" and reads from it.
            StreamReader girlNames = new StreamReader("GirlNames.txt");
            return girlNames;
        }

        private void boyNameSearchButton_Click(object sender, EventArgs e)
        {
            const int BOY_NAMES_SIZE = 200;
            int boyNamesIndex = 0;
            string userName = boyNameTextBox.Text;
            // Opens and reads a file named 'BoysName.txt'
            StreamReader boyNames = readBoyNamesFile();
            // Creates an array initialized with the number of lines in the opened file
            string[] boyNamesArray = new string[BOY_NAMES_SIZE];

            // While loop that reads the opened file and set each line of it to an element in the array.
            while (!boyNames.EndOfStream)
            {
                string boyNameLine = boyNames.ReadLine();
                boyNamesArray[boyNamesIndex] += boyNameLine;
                boyNamesIndex++;
            }
            boyNames.Close();

            //For loop that goes through the array to see if the name the user entered was a popular name.
            for (int boyNamesArrayIndex = 0; boyNamesArrayIndex < boyNamesArray.Length; boyNamesArrayIndex++)
            {
                if (boyNamesArray[boyNamesArrayIndex] == userName)
                {
                    MessageBox.Show(userName + " was one of the most popular names for boys between 2000-2009!");
                }

            }
        }

        private void girlNameSearchButton_Click(object sender, EventArgs e)
        {
            const int GIRL_NAMES_SIZE = 200;
            int girlNamesIndex = 0;
            string userName = girlNamesTextBox.Text;
            // Opens and reads a file named 'BoysName.txt'
            StreamReader girlNames = readGirlNamesFile();
            // Creates an array initialized with the number of lines in the opened file
            string[] girlNamesArray = new string[GIRL_NAMES_SIZE];

            // While loop that reads the opened file and set each line of it to an element in the array.
            while (!girlNames.EndOfStream)
            {
                string boyNameLine = girlNames.ReadLine();
                girlNamesArray[girlNamesIndex] += boyNameLine;
                girlNamesIndex++;
            }
            girlNames.Close();

            //For loop that goes through the array to see if the name the user entered was a popular name.
            for (int girlNamesArrayIndex = 0; girlNamesArrayIndex < girlNamesArray.Length; girlNamesArrayIndex++)
            {
                if (girlNamesArray[girlNamesArrayIndex] == userName)
                {
                    MessageBox.Show(userName + " was one of the most popular names for girls between 2000-2009!");
                }

            }
        }

        private void unisexNameSearchButton_Click(object sender, EventArgs e)
        {
            const int BOY_NAMES_SIZE = 200;
            int boyNamesIndex = 0;
            string boyName = unisexNameTextBox.Text;
            // Opens and reads a file named 'BoysName.txt'
            StreamReader boyNames = readBoyNamesFile();
            // Creates an array initialized with the number of lines in the opened file
            string[] boyNamesArray = new string[BOY_NAMES_SIZE];

            // While loop that reads the opened file and set each line of it to an element in the array.
            while (!boyNames.EndOfStream)
            {
                string boyNameLine = boyNames.ReadLine();
                boyNamesArray[boyNamesIndex] += boyNameLine;
                boyNamesIndex++;
            }
            boyNames.Close();

            //For loop that goes through the array to see if the name the user entered was a popular name.
            for (int boyNamesArrayIndex = 0; boyNamesArrayIndex < boyNamesArray.Length; boyNamesArrayIndex++)
            {
                if (boyNamesArray[boyNamesArrayIndex] == boyName)
                {
                    MessageBox.Show(boyName + " was one of the most popular names for boys between 2000-2009!");
                }

            }

            const int GIRL_NAMES_SIZE = 200;
            int girlNamesIndex = 0;
            string girlName = unisexNameTextBox.Text;
            // Opens and reads a file named 'BoysName.txt'
            StreamReader girlNames = readGirlNamesFile();
            // Creates an array initialized with the number of lines in the opened file
            string[] girlNamesArray = new string[GIRL_NAMES_SIZE];

            // While loop that reads the opened file and set each line of it to an element in the array.
            while (!girlNames.EndOfStream)
            {
                string boyNameLine = girlNames.ReadLine();
                girlNamesArray[girlNamesIndex] += boyNameLine;
                girlNamesIndex++;
            }
            girlNames.Close();

            //For loop that goes through the array to see if the name the user entered was a popular name.
            for (int girlNamesArrayIndex = 0; girlNamesArrayIndex < girlNamesArray.Length; girlNamesArrayIndex++)
            {
                if (girlNamesArray[girlNamesArrayIndex] == girlName)
                {
                    MessageBox.Show(girlName + " was one of the most popular names for girls between 2000-2009!");
                }

            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the program
            this.Close();
        }
    }
}
