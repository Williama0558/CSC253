﻿namespace Sentence_Capitalizer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sentenceLabel = new System.Windows.Forms.Label();
            this.sentenceTextBox = new System.Windows.Forms.TextBox();
            this.capitalizedLabel = new System.Windows.Forms.Label();
            this.formattedSentenceLabel = new System.Windows.Forms.Label();
            this.capitalizeButton = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // sentenceLabel
            // 
            this.sentenceLabel.AutoSize = true;
            this.sentenceLabel.Location = new System.Drawing.Point(12, 45);
            this.sentenceLabel.Name = "sentenceLabel";
            this.sentenceLabel.Size = new System.Drawing.Size(123, 13);
            this.sentenceLabel.TabIndex = 0;
            this.sentenceLabel.Text = "Uncapitalized Sentence:";
            // 
            // sentenceTextBox
            // 
            this.sentenceTextBox.Location = new System.Drawing.Point(141, 42);
            this.sentenceTextBox.Name = "sentenceTextBox";
            this.sentenceTextBox.Size = new System.Drawing.Size(296, 20);
            this.sentenceTextBox.TabIndex = 1;
            // 
            // capitalizedLabel
            // 
            this.capitalizedLabel.AutoSize = true;
            this.capitalizedLabel.Location = new System.Drawing.Point(22, 82);
            this.capitalizedLabel.Name = "capitalizedLabel";
            this.capitalizedLabel.Size = new System.Drawing.Size(113, 13);
            this.capitalizedLabel.TabIndex = 2;
            this.capitalizedLabel.Text = "Capitalized Sentence: ";
            // 
            // formattedSentenceLabel
            // 
            this.formattedSentenceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.formattedSentenceLabel.Location = new System.Drawing.Point(141, 81);
            this.formattedSentenceLabel.Name = "formattedSentenceLabel";
            this.formattedSentenceLabel.Size = new System.Drawing.Size(296, 23);
            this.formattedSentenceLabel.TabIndex = 3;
            // 
            // capitalizeButton
            // 
            this.capitalizeButton.Location = new System.Drawing.Point(25, 148);
            this.capitalizeButton.Name = "capitalizeButton";
            this.capitalizeButton.Size = new System.Drawing.Size(75, 23);
            this.capitalizeButton.TabIndex = 4;
            this.capitalizeButton.Text = "Capitalize";
            this.capitalizeButton.UseVisualStyleBackColor = true;
            this.capitalizeButton.Click += new System.EventHandler(this.capitalizeButton_Click);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(185, 148);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 23);
            this.resetButton.TabIndex = 5;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(449, 186);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.capitalizeButton);
            this.Controls.Add(this.formattedSentenceLabel);
            this.Controls.Add(this.capitalizedLabel);
            this.Controls.Add(this.sentenceTextBox);
            this.Controls.Add(this.sentenceLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label sentenceLabel;
        private System.Windows.Forms.TextBox sentenceTextBox;
        private System.Windows.Forms.Label capitalizedLabel;
        private System.Windows.Forms.Label formattedSentenceLabel;
        private System.Windows.Forms.Button capitalizeButton;
        private System.Windows.Forms.Button resetButton;
    }
}

