﻿/**
* 10/21/18
* CSC 253
* Aaron Williams
* This program capitalizes sentences the user enters in
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sentence_Capitalizer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void capitalizeButton_Click(object sender, EventArgs e)
        {
            // Gets a sentence from the user
            string userSentence = sentenceTextBox.Text;

            // Sends the sentence to a method to be capitalized
            string formattedSentence = capitalizeSentence(userSentence);
            formattedSentenceLabel.Text = formattedSentence;
        }

        private string capitalizeSentence(string userSentence)
        {
            // Method for capitalizing the sentence
            char[] letters = new char[userSentence.Length];

            // Loop that goes through the sentence to test each character
            for (int index = 0; index < userSentence.Length; index++)
            {
                char letter = userSentence[index];

                // Capitalizes the first letter the user enters in
                if (index == 0)
                {
                    letter = char.ToUpper(letter);
                    letters[index] = letter;
                }

                // Checks to see if a letter comes after punctuation so that it can be capitalized
                if (letter == '.' || letter == '!' || letter == '?')
                {
                    letters[index] = letter;
                    if(!(index + 2 >= userSentence.Length))
                    {
                        index++;
                        letter = userSentence[index];
                        letters[index] = letter;
                        index++;
                        letter = userSentence[index];
                        letter = char.ToUpper(letter);
                        letters[index] = letter;
                    }
                }
                else
                {
                    letters[index] = letter;
                }
            }

            // Returns the letters char dictionary as a string
            return string.Join("", letters);
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            // Resets all of the fields on the form
            sentenceTextBox.Text = "";
            formattedSentenceLabel.Text = "";
        }
    }
}
