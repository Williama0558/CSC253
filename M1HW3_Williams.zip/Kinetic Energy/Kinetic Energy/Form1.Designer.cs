﻿namespace Kinetic_Energy
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.massTextBox = new System.Windows.Forms.TextBox();
            this.massLabel = new System.Windows.Forms.Label();
            this.velocityTextBox = new System.Windows.Forms.TextBox();
            this.velocityLabel = new System.Windows.Forms.Label();
            this.kineticEnergyLabel = new System.Windows.Forms.Label();
            this.kineticLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // massTextBox
            // 
            this.massTextBox.Location = new System.Drawing.Point(146, 27);
            this.massTextBox.Name = "massTextBox";
            this.massTextBox.Size = new System.Drawing.Size(100, 20);
            this.massTextBox.TabIndex = 0;
            // 
            // massLabel
            // 
            this.massLabel.AutoSize = true;
            this.massLabel.Location = new System.Drawing.Point(64, 30);
            this.massLabel.Name = "massLabel";
            this.massLabel.Size = new System.Drawing.Size(76, 13);
            this.massLabel.TabIndex = 1;
            this.massLabel.Text = "Object\'s Mass:";
            // 
            // velocityTextBox
            // 
            this.velocityTextBox.Location = new System.Drawing.Point(146, 63);
            this.velocityTextBox.Name = "velocityTextBox";
            this.velocityTextBox.Size = new System.Drawing.Size(100, 20);
            this.velocityTextBox.TabIndex = 2;
            // 
            // velocityLabel
            // 
            this.velocityLabel.AutoSize = true;
            this.velocityLabel.Location = new System.Drawing.Point(52, 66);
            this.velocityLabel.Name = "velocityLabel";
            this.velocityLabel.Size = new System.Drawing.Size(88, 13);
            this.velocityLabel.TabIndex = 3;
            this.velocityLabel.Text = "Object\'s Velocity:";
            // 
            // kineticEnergyLabel
            // 
            this.kineticEnergyLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.kineticEnergyLabel.Location = new System.Drawing.Point(146, 97);
            this.kineticEnergyLabel.Name = "kineticEnergyLabel";
            this.kineticEnergyLabel.Size = new System.Drawing.Size(100, 22);
            this.kineticEnergyLabel.TabIndex = 4;
            // 
            // kineticLabel
            // 
            this.kineticLabel.AutoSize = true;
            this.kineticLabel.Location = new System.Drawing.Point(21, 98);
            this.kineticLabel.Name = "kineticLabel";
            this.kineticLabel.Size = new System.Drawing.Size(119, 13);
            this.kineticLabel.TabIndex = 5;
            this.kineticLabel.Text = "Object\'s Kinetic Energy:";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(23, 144);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 6;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(104, 144);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 23);
            this.resetButton.TabIndex = 7;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(185, 144);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 8;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(282, 198);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.kineticLabel);
            this.Controls.Add(this.kineticEnergyLabel);
            this.Controls.Add(this.velocityLabel);
            this.Controls.Add(this.velocityTextBox);
            this.Controls.Add(this.massLabel);
            this.Controls.Add(this.massTextBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox massTextBox;
        private System.Windows.Forms.Label massLabel;
        private System.Windows.Forms.TextBox velocityTextBox;
        private System.Windows.Forms.Label velocityLabel;
        private System.Windows.Forms.Label kineticEnergyLabel;
        private System.Windows.Forms.Label kineticLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button exitButton;
    }
}

