﻿/**
* 09/9/18
* CSC 253
* Aaron Williams
* This program will calculate the kinetic energy of an object
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kinetic_Energy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Method that calculates the kinetic energy of the object
        private double calculateEnergy(double mass, double velocity)
        {
            double kineticEnergy;
            kineticEnergy = .5 * mass * (velocity * velocity);
            return kineticEnergy;
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double objectMass;
            double objectVelocity;
            double kineticEnergy;
            // If statements for getting the mass and velocity of an object
            if (double.TryParse(massTextBox.Text, out objectMass))
            {
                if (double.TryParse(velocityTextBox.Text, out objectVelocity))
                {
                    kineticEnergy = calculateEnergy(objectMass, objectVelocity);
                    kineticEnergyLabel.Text = kineticEnergy.ToString();
                }

                else
                {
                    velocityTextBox.Text = "Invalid input";
                }
            }
            else
            {
                massTextBox.Text = "Invalid input";
            }
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            // Clears the text fields in the program
            massTextBox.Text = "";
            velocityTextBox.Text = "";
            kineticEnergyLabel.Text = "";
            massTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Exits the program
            this.Close();
        }
    }
}
