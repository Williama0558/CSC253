﻿/**
* 08/31/18
* CSC 253
* Aaron Williams
* This program will tell the user how many points they've earned based on the number of books they've purchased.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_Club_Points
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Gets input from the user and decides how many points they earned based on the number they entered.
            // Displays an error if invalid input is entered.
            int booksPurchased;
            if (int.TryParse(booksPurchasedTextBox.Text, out booksPurchased))
            {
                if (booksPurchased < 0)
                {
                    MessageBox.Show("You can't purchase a negative amount of books");
                }
                else if (booksPurchased == 0)
                {
                    pointsEarnedLabel.Text = "0";
                }
                else if (booksPurchased == 1)
                {
                    pointsEarnedLabel.Text = "5";
                }
                else if (booksPurchased == 2)
                {
                    pointsEarnedLabel.Text = "15";
                }
                else if (booksPurchased == 3)
                {
                    pointsEarnedLabel.Text = "30";
                }
                else
                {
                    pointsEarnedLabel.Text = "60";
                }
            }
            else
            {
                MessageBox.Show("Invalid amount");
            }
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            // Clears all fields on the form
            booksPurchasedTextBox.Text = "";
            pointsEarnedLabel.Text = "";
            booksPurchasedTextBox.Focus();
            
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the program
            this.Close();
        }
    }
}
