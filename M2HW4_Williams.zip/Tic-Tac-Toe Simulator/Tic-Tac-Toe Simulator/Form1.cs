﻿/**
* 09/30/18
* CSC 253
* Aaron Williams
* This program simulates a game of Tic-Tac-Toe
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tic_Tac_Toe_Simulator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayNumbers(int[,]ticTacToeArray)
        {
            // Displays the random number that was assigned to each element
            topLeftDisplayLabel.Text = ticTacToeArray[0, 0].ToString();
            topMiddleDisplayLabel.Text = ticTacToeArray[0, 1].ToString();
            topRightDisplayLabel.Text = ticTacToeArray[0, 2].ToString();
            middleLeftDisplayLabel.Text = ticTacToeArray[1, 0].ToString();
            middleDisplayLabel.Text = ticTacToeArray[1, 1].ToString();
            middleRightDisplayLabel.Text = ticTacToeArray[1, 2].ToString();
            bottomLeftDisplayLabel.Text = ticTacToeArray[2, 0].ToString();
            bottomMiddleDisplayLabel.Text = ticTacToeArray[2, 1].ToString();
            bottomRightDisplayLabel.Text = ticTacToeArray[2, 2].ToString();
        }

        private void checkVictoryConditions(int[,] ticTacToeArray)
        {
            // Checks to see if X or O won the game
            if (ticTacToeArray[0, 0] == 1 && ticTacToeArray[0, 1] == 1 && ticTacToeArray[0, 2] == 1 ||
                ticTacToeArray[1, 0] == 1 && ticTacToeArray[1, 1] == 1 && ticTacToeArray[1, 2] == 1 ||
                ticTacToeArray[2, 0] == 1 && ticTacToeArray[2, 1] == 1 && ticTacToeArray[2, 2] == 1 ||
                ticTacToeArray[0, 0] == 1 && ticTacToeArray[1, 0] == 1 && ticTacToeArray[2, 0] == 1 ||
                ticTacToeArray[0, 1] == 1 && ticTacToeArray[1, 1] == 1 && ticTacToeArray[2, 1] == 1 ||
                ticTacToeArray[0, 2] == 1 && ticTacToeArray[1, 2] == 1 && ticTacToeArray[2, 2] == 1 ||
                ticTacToeArray[0, 0] == 1 && ticTacToeArray[1, 1] == 1 && ticTacToeArray[2, 2] == 1 ||
                ticTacToeArray[0, 2] == 1 && ticTacToeArray[1, 1] == 1 && ticTacToeArray[2, 0] == 1)
            {
                victoryLabel.Text = "X wins!";
            }

            else if (ticTacToeArray[0, 0] == 0 && ticTacToeArray[0, 1] == 0 && ticTacToeArray[0, 2] == 0 ||
                     ticTacToeArray[1, 0] == 0 && ticTacToeArray[1, 1] == 0 && ticTacToeArray[1, 2] == 0 ||
                     ticTacToeArray[2, 0] == 0 && ticTacToeArray[2, 1] == 0 && ticTacToeArray[2, 2] == 0 ||
                     ticTacToeArray[0, 0] == 0 && ticTacToeArray[1, 0] == 0 && ticTacToeArray[2, 0] == 0 ||
                     ticTacToeArray[0, 1] == 0 && ticTacToeArray[1, 1] == 0 && ticTacToeArray[2, 1] == 0 ||
                     ticTacToeArray[0, 2] == 0 && ticTacToeArray[1, 2] == 0 && ticTacToeArray[2, 2] == 0 ||
                     ticTacToeArray[0, 0] == 0 && ticTacToeArray[1, 1] == 0 && ticTacToeArray[2, 2] == 0 ||
                     ticTacToeArray[0, 2] == 0 && ticTacToeArray[1, 1] == 0 && ticTacToeArray[2, 0] == 0)
            {
                victoryLabel.Text = "O wins!";
            }

            else
            {
                victoryLabel.Text = "Both players tied";
            }

        }

        private void newGameButton_Click(object sender, EventArgs e)
        {


            // Random object that will determine if a square has an X or an O
            Random rand = new Random();

            // Constants that control how big the 2D array will be
            const int MAX_ROWS = 3;
            const int MAX_COLUMNS = 3;

            // Array that will hold information for each of the squares in the tic-tac-toe board
            int[,] ticTacToeArray = new int[MAX_ROWS, MAX_COLUMNS];

            // Loops that fill the array with random numbers
            for (int row = 0; row < MAX_ROWS; row++)
            {
                for (int column = 0; column < MAX_COLUMNS; column++)
                {
                    ticTacToeArray[row, column] = rand.Next(2);
                }
            }

            // Displays the number in each square
            displayNumbers(ticTacToeArray);

            // Checks to see who wins
            checkVictoryConditions(ticTacToeArray);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
