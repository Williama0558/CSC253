﻿namespace Tic_Tac_Toe_Simulator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.topLeftDisplayLabel = new System.Windows.Forms.Label();
            this.topMiddleDisplayLabel = new System.Windows.Forms.Label();
            this.topRightDisplayLabel = new System.Windows.Forms.Label();
            this.middleLeftDisplayLabel = new System.Windows.Forms.Label();
            this.middleDisplayLabel = new System.Windows.Forms.Label();
            this.middleRightDisplayLabel = new System.Windows.Forms.Label();
            this.bottomLeftDisplayLabel = new System.Windows.Forms.Label();
            this.bottomMiddleDisplayLabel = new System.Windows.Forms.Label();
            this.bottomRightDisplayLabel = new System.Windows.Forms.Label();
            this.victoryLabel = new System.Windows.Forms.Label();
            this.newGameButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // topLeftDisplayLabel
            // 
            this.topLeftDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.topLeftDisplayLabel.Location = new System.Drawing.Point(13, 13);
            this.topLeftDisplayLabel.Name = "topLeftDisplayLabel";
            this.topLeftDisplayLabel.Size = new System.Drawing.Size(100, 102);
            this.topLeftDisplayLabel.TabIndex = 0;
            this.topLeftDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // topMiddleDisplayLabel
            // 
            this.topMiddleDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.topMiddleDisplayLabel.Location = new System.Drawing.Point(132, 13);
            this.topMiddleDisplayLabel.Name = "topMiddleDisplayLabel";
            this.topMiddleDisplayLabel.Size = new System.Drawing.Size(100, 102);
            this.topMiddleDisplayLabel.TabIndex = 1;
            this.topMiddleDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // topRightDisplayLabel
            // 
            this.topRightDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.topRightDisplayLabel.Location = new System.Drawing.Point(252, 13);
            this.topRightDisplayLabel.Name = "topRightDisplayLabel";
            this.topRightDisplayLabel.Size = new System.Drawing.Size(100, 102);
            this.topRightDisplayLabel.TabIndex = 2;
            this.topRightDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // middleLeftDisplayLabel
            // 
            this.middleLeftDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.middleLeftDisplayLabel.Location = new System.Drawing.Point(13, 129);
            this.middleLeftDisplayLabel.Name = "middleLeftDisplayLabel";
            this.middleLeftDisplayLabel.Size = new System.Drawing.Size(100, 102);
            this.middleLeftDisplayLabel.TabIndex = 3;
            this.middleLeftDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // middleDisplayLabel
            // 
            this.middleDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.middleDisplayLabel.Location = new System.Drawing.Point(132, 129);
            this.middleDisplayLabel.Name = "middleDisplayLabel";
            this.middleDisplayLabel.Size = new System.Drawing.Size(100, 102);
            this.middleDisplayLabel.TabIndex = 4;
            this.middleDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // middleRightDisplayLabel
            // 
            this.middleRightDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.middleRightDisplayLabel.Location = new System.Drawing.Point(252, 129);
            this.middleRightDisplayLabel.Name = "middleRightDisplayLabel";
            this.middleRightDisplayLabel.Size = new System.Drawing.Size(100, 102);
            this.middleRightDisplayLabel.TabIndex = 5;
            this.middleRightDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bottomLeftDisplayLabel
            // 
            this.bottomLeftDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bottomLeftDisplayLabel.Location = new System.Drawing.Point(13, 243);
            this.bottomLeftDisplayLabel.Name = "bottomLeftDisplayLabel";
            this.bottomLeftDisplayLabel.Size = new System.Drawing.Size(100, 102);
            this.bottomLeftDisplayLabel.TabIndex = 6;
            this.bottomLeftDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bottomMiddleDisplayLabel
            // 
            this.bottomMiddleDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bottomMiddleDisplayLabel.Location = new System.Drawing.Point(132, 243);
            this.bottomMiddleDisplayLabel.Name = "bottomMiddleDisplayLabel";
            this.bottomMiddleDisplayLabel.Size = new System.Drawing.Size(100, 102);
            this.bottomMiddleDisplayLabel.TabIndex = 7;
            this.bottomMiddleDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bottomRightDisplayLabel
            // 
            this.bottomRightDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bottomRightDisplayLabel.Location = new System.Drawing.Point(252, 243);
            this.bottomRightDisplayLabel.Name = "bottomRightDisplayLabel";
            this.bottomRightDisplayLabel.Size = new System.Drawing.Size(100, 102);
            this.bottomRightDisplayLabel.TabIndex = 8;
            this.bottomRightDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // victoryLabel
            // 
            this.victoryLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.victoryLabel.Location = new System.Drawing.Point(13, 366);
            this.victoryLabel.Name = "victoryLabel";
            this.victoryLabel.Size = new System.Drawing.Size(339, 23);
            this.victoryLabel.TabIndex = 9;
            this.victoryLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // newGameButton
            // 
            this.newGameButton.Location = new System.Drawing.Point(92, 408);
            this.newGameButton.Name = "newGameButton";
            this.newGameButton.Size = new System.Drawing.Size(75, 23);
            this.newGameButton.TabIndex = 10;
            this.newGameButton.Text = "New Game";
            this.newGameButton.UseVisualStyleBackColor = true;
            this.newGameButton.Click += new System.EventHandler(this.newGameButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(194, 408);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(382, 455);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.newGameButton);
            this.Controls.Add(this.victoryLabel);
            this.Controls.Add(this.bottomRightDisplayLabel);
            this.Controls.Add(this.bottomMiddleDisplayLabel);
            this.Controls.Add(this.bottomLeftDisplayLabel);
            this.Controls.Add(this.middleRightDisplayLabel);
            this.Controls.Add(this.middleDisplayLabel);
            this.Controls.Add(this.middleLeftDisplayLabel);
            this.Controls.Add(this.topRightDisplayLabel);
            this.Controls.Add(this.topMiddleDisplayLabel);
            this.Controls.Add(this.topLeftDisplayLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label topLeftDisplayLabel;
        private System.Windows.Forms.Label topMiddleDisplayLabel;
        private System.Windows.Forms.Label topRightDisplayLabel;
        private System.Windows.Forms.Label middleLeftDisplayLabel;
        private System.Windows.Forms.Label middleDisplayLabel;
        private System.Windows.Forms.Label middleRightDisplayLabel;
        private System.Windows.Forms.Label bottomLeftDisplayLabel;
        private System.Windows.Forms.Label bottomMiddleDisplayLabel;
        private System.Windows.Forms.Label bottomRightDisplayLabel;
        private System.Windows.Forms.Label victoryLabel;
        private System.Windows.Forms.Button newGameButton;
        private System.Windows.Forms.Button exitButton;
    }
}

