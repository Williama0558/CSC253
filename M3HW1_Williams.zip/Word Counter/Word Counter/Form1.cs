﻿/**
* 10/12/18
* CSC 253
* Aaron Williams
* This program counts the total amount of words in a sentence
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Word_Counter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string[] countWords(string userString)
        {
            // Method that splits the sentence the user enters and stores each word in an array
            string[] userStringArray = userString.Split(null);
            return userStringArray;
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            int counter = 0;
            string userString = userStringTextBox.Text;
            string[] userStringArray = countWords(userString);
            foreach (string word in userStringArray)
            {
                counter += 1;
            }
            totalDisplayLabel.Text = counter.ToString();
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            userStringTextBox.Text = "";
            totalDisplayLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
