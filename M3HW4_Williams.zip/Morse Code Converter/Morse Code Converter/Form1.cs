﻿/**
* 10/21/18
* CSC 253
* Aaron Williams
* This program converts a sentence to morse code
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Morse_Code_Converter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            // Creates a dictionary to store all morse code values and assigns a character as its key
            Dictionary<char, string> morseCodeDict = new Dictionary<char, string>();

            morseCodeDict.Add(' ', "   ");
            morseCodeDict.Add(',', "--..--");
            morseCodeDict.Add('.', ".-.-.-");
            morseCodeDict.Add('?', "..--..");
            morseCodeDict.Add('0', "-----");
            morseCodeDict.Add('1', ".----");
            morseCodeDict.Add('2', "..---");
            morseCodeDict.Add('3', "...--");
            morseCodeDict.Add('4', "....-");
            morseCodeDict.Add('5', ".....");
            morseCodeDict.Add('6', "-....");
            morseCodeDict.Add('7', "--...");
            morseCodeDict.Add('8', "---..");
            morseCodeDict.Add('9', "----.");
            morseCodeDict.Add('A', ".-");
            morseCodeDict.Add('B', "-...");
            morseCodeDict.Add('C', "-.-.");
            morseCodeDict.Add('D', "-..");
            morseCodeDict.Add('E', ".");
            morseCodeDict.Add('F', "..-.");
            morseCodeDict.Add('G', "--.");
            morseCodeDict.Add('H', "....");
            morseCodeDict.Add('I', "..");
            morseCodeDict.Add('J', ".---");
            morseCodeDict.Add('K', "-.-");
            morseCodeDict.Add('L', ".-..");
            morseCodeDict.Add('M', "---");
            morseCodeDict.Add('N', "-.");
            morseCodeDict.Add('O', "---");
            morseCodeDict.Add('P', ".--.");
            morseCodeDict.Add('Q', "--.-");
            morseCodeDict.Add('R', ".-.");
            morseCodeDict.Add('S', "...");
            morseCodeDict.Add('T', "-");
            morseCodeDict.Add('U', "..-");
            morseCodeDict.Add('V', "...-");
            morseCodeDict.Add('W', ".--");
            morseCodeDict.Add('X', "-..-");
            morseCodeDict.Add('Y', "-.--");
            morseCodeDict.Add('Z', "--..");

            // Gets a string from the user
            string userString = userStringTextBox.Text;

            // Creates a char dictionary to store every character in the user entered string
            char[] letters = new char[userString.Length];
            string result;
            string[] morseCodeString = new string[userString.Length];

            // Loop that goes through the string and replaces each character with its morse code equivalent
            for (int index = 0; index < userString.Length; index++)
            {
                char letter = userString[index];
                letter = char.ToUpper(letter);
                if (morseCodeDict.TryGetValue(letter, out result))
                {
                    morseCodeString[index] = result;
                }
            }

            morseCodeLabel.Text = string.Join("", morseCodeString);
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            // Resets fields on the form
            userStringTextBox.Text = "";
            morseCodeLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the program
            this.Close();
        }
    }
}
