﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Catacombs_of_Bool
{
    class Rooms
    {
        // Fields for the Rooms class
        private string _roomName;
        private string _roomDescription;
        private string _roomExits;
        private object[] _roomObjects;

        public Rooms()
        {
            string _roomName = "";
            string _roomDescription = "";
            string _roomExits = "";
            object[] _roomObjects;
        }

        public Rooms(string roomName, string roomDescription, string roomExits, object[] roomObjects)
        {
            string _roomName = roomName;
            string _roomDescription = roomDescription;
            string _roomExits = roomExits;
            object[] _roomObjects = roomObjects;
        }

        public string roomName
        {
            get { return _roomName; }
            set { _roomName = value; }
        }

        public string roomDescription
        {
            get { return _roomDescription; }
            set { _roomDescription = value; }
        }

        public string roomExits
        {
            get { return _roomExits; }
            set { _roomExits = value; }
        }

        public object[] roomObjects
        {
            get { return _roomObjects; }
            set { _roomObjects = value; }
        }
    }

}
