﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Catacombs_of_Bool
{
    class Potions
    {
        // Fields for the Potions class

        private string _name;
        private string _description;
        private int _recoveryValue;

        public Potions()
        {
            // No arg constructor

            _name = "";
            _description = "";
            _recoveryValue = 0;
        }

        public Potions(string name, int recoveryValue)
        {
            // Constructor that takes arguments for each field

            _name = name;
            _description = description;
            _recoveryValue = recoveryValue;
        }


        // Methods that get and set information for the fields of the class

        public string name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string description
        {
            get { return _description; }
            set { _description = value; }
        }

        public int recoveryValue
        {
            get { return _recoveryValue; }
            set { _recoveryValue = value; }
        }

    }
}
