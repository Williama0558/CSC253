﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Catacombs_of_Bool
{
    class PotionGeneration
    {
        public static StreamReader potionFile;

        public static Potions[] createPotions()
        {
            // Will look for the correct text file and will create potion objects using that information.

            potionFile = File.OpenText("Potions\\HealingPotion.txt");
            Potions healthPotion = new Potions();
            healthPotion.name = potionFile.ReadLine();
            healthPotion.description = potionFile.ReadLine();
            healthPotion.recoveryValue = int.Parse(potionFile.ReadLine());
            potionFile.Close();

            potionFile = File.OpenText("Potions\\GreaterHealingPotion.txt");
            Potions greaterHealthPotion = new Potions();
            greaterHealthPotion.name = potionFile.ReadLine();
            greaterHealthPotion.description = potionFile.ReadLine();
            greaterHealthPotion.recoveryValue = int.Parse(potionFile.ReadLine());
            potionFile.Close();


            // Returns a list of mobs created from this method
            Potions[] potionArray = { healthPotion, greaterHealthPotion };
            return potionArray;
        }
    }
}
