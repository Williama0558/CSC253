﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Catacombs_of_Bool
{
    class WeaponGeneration
    {
        public static StreamReader weaponFile;

        public static Weapons[] createWeapons()
        {
            // Will look for the correct text file and will create weapon objects using that information.

            weaponFile = File.OpenText("Weapons\\Axe.txt");
            Weapons axe = new Weapons();
            axe.name = weaponFile.ReadLine();
            axe.description = weaponFile.ReadLine();
            axe.type = weaponFile.ReadLine();
            axe.attackValue = int.Parse(weaponFile.ReadLine());
            weaponFile.Close();

            weaponFile = File.OpenText("Weapons\\Mace.txt");
            Weapons mace = new Weapons();
            mace.name = weaponFile.ReadLine();
            mace.description = weaponFile.ReadLine();
            mace.type = weaponFile.ReadLine();
            mace.attackValue = int.Parse(weaponFile.ReadLine());
            weaponFile.Close();

            weaponFile = File.OpenText("Weapons\\Spear.txt");
            Weapons spear = new Weapons();
            spear.name = weaponFile.ReadLine();
            spear.description = weaponFile.ReadLine();
            spear.type = weaponFile.ReadLine();
            spear.attackValue = int.Parse(weaponFile.ReadLine());
            weaponFile.Close();

            weaponFile = File.OpenText("Weapons\\Sword.txt");
            Weapons sword = new Weapons();
            sword.name = weaponFile.ReadLine();
            sword.description = weaponFile.ReadLine();
            sword.type = weaponFile.ReadLine();
            sword.attackValue = int.Parse(weaponFile.ReadLine());
            weaponFile.Close();

            // Returns a list of mobs created from this method
            Weapons[] weaponArray = { axe, mace, spear, sword };
            return weaponArray;
        }
    }
}
