﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Catacombs_of_Bool
{
    class Monster
    {
        private string _name;
        private string _description;
        private int _health;
        private int _agility;
        private int _armorValue;

        public Monster()
        {
            // No arg constructor

            _name = "";
            _description = "";
            _health = 0;
            _agility = 0;
            _armorValue = 0;
        }

        public Monster(string name, string description, int health, int agility, int armorValue)
        {
            // Constructor that takes arguments for each field

            _name = name;
            _description = description;
            _health = health;
            _agility = agility;
            _armorValue = armorValue;
        }

        public string name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string description
        {
            get { return _description; }
            set { _description = value; }
        }

        public int health
        {
            get { return _health; }
            set { _health = value; }
        }

        public int agility
        {
            get { return _agility; }
            set { _agility = value; }
        }

        public int armorValue
        {
            get { return _armorValue; }
            set { _agility = value; }
        }
    }
}
