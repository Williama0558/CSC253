﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Catacombs_of_Bool
{
    class Weapons
    {
        // Fields for the Potions class

        private string _name;
        private string _description;
        private string _type;
        private int _attackValue;

        public Weapons()
        {
            // No arg constructor

            _name = "";
            _description = "";
            _type = "";
            _attackValue = 0;
        }

        public Weapons(string name, int recoveryValue)
        {
            // Constructor that takes arguments for each field

            _name = name;
            _description = description;
            _type = type;
            _attackValue = attackValue;
        }


        // Methods that get and set information for the fields of the class

        public string name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string description
        {
            get { return _description; }
            set { _description = value; }
        }

        public string type
        {
            get { return _type; }
            set { _type = value; }
        }

        public int attackValue
        {
            get { return _attackValue; }
            set { _attackValue = value; }
        }

    }
}
