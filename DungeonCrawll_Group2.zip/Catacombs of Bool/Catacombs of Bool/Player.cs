﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Catacombs_of_Bool
{

    class Player
    {
        // Fields for the player class

        private string _playerName;
        private string _password;
        private string _playerClass;
        private string _playerRace;

        public Player()
        {
            // No arg constructor

            _playerName = "";
            _password = "";
            _playerClass = "";
            _playerRace = "";
        }

        public Player(string playerName, string password, string playerClass, string playerRace, int[,] playerPosition)
        {
            // Constructor that takes arguments for each field

            _playerName = playerName;
            _password = password;
            _playerClass = playerClass;
            _playerRace = playerRace;
        }


        // Methods that get and set information for the fields of the class

        public string playerName
        {
            get { return _playerName; }
            set { _playerName = value; }
        }

        public string password
        {
            get { return _password; }
            set { _password = value; }
        }

        public string playerRace
        {
            get { return _playerRace; }
            set { _playerRace = value; }
        }

        public string playerClass
        {
            get { return _playerClass; }
            set { _playerClass = value; }
        }

    }

}

