﻿/**
* 11/11/18
* CSC 253
* Aaron Williams
* This program holds information in a class for team leaders
* **/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeamLeader
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            // Variables that will be passed into classes
            double payRate = 0.0;
            int shiftNumber = 0;
            decimal monthlyBonus = 0m;
            int requiredHours = 0;
            int attendedHours = 0;

            // Creates a production worker object and initializes some variables
            TeamLeader worker = new TeamLeader();
            worker.Name = nameTextBox.Text;
            worker.Number = numberTextBox.Text;

            // Checks to make sure proper input is entered in the shiftNumber field.
            if (int.TryParse(shiftTextBox.Text, out shiftNumber))
            {
                if (shiftNumber == 1 || shiftNumber == 2)
                {
                    worker.ShiftNumber = int.Parse(shiftTextBox.Text);
                }
                else
                {
                    MessageBox.Show("Invalid shift number entered");
                }
            }
            else
            {
                MessageBox.Show("Invalid input for shift number entered");
            }

            // Checks to make sure proper input is entered in the pay rate field.
            if (double.TryParse(payRateTextBox.Text, out payRate))
            {
                worker.PayRate = double.Parse(payRateTextBox.Text);
            }
            else
            {
                MessageBox.Show("Invalid input for pay rate entered");
            }

            // Checks to make sure proper input is entered in the bonus field.
            if (decimal.TryParse(bonusTextBox.Text, out monthlyBonus))
            {
                worker.MonthlyBonus = decimal.Parse(bonusTextBox.Text);
            }
            else
            {
                MessageBox.Show("Invalid input for bonus entered");
            }

            // Checks to make sure proper input is entered in the required hours field.
            if (int.TryParse(requiredHoursTextBox.Text, out requiredHours))
            {
                worker.RequiredHours = int.Parse(requiredHoursTextBox.Text);
            }
            else
            {
                MessageBox.Show("Invalid input for required hours entered");
            }

            // Checks to make sure proper input is entered in the attended hours field.
            if (int.TryParse(attendedHoursTextBox.Text, out attendedHours))
            {
                worker.AttendedHours = int.Parse(attendedHoursTextBox.Text);
            }
            else
            {
                MessageBox.Show("Invalid input for attended hours entered");
            }

            // Displays output
            nameDisplayLabel.Text = worker.Name;
            numberDisplayLabel.Text = worker.Number;
            shiftDisplayLabel.Text = worker.ShiftNumber.ToString();
            payRateDisplayLabel.Text = worker.PayRate.ToString();
            bonusDisplayLabel.Text = worker.MonthlyBonus.ToString();
            requiredHoursDisplayLabel.Text = worker.RequiredHours.ToString();
            attendedHoursDisplayLabel.Text = worker.AttendedHours.ToString();
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            // Erases all text in the program
            nameTextBox.Text = "";
            numberTextBox.Text = "";
            shiftTextBox.Text = "";
            payRateTextBox.Text = "";
            bonusTextBox.Text = "";
            requiredHoursTextBox.Text = "";
            attendedHoursTextBox.Text = "";

            nameDisplayLabel.Text = "";
            numberDisplayLabel.Text = "";
            shiftDisplayLabel.Text = "";
            payRateDisplayLabel.Text = "";
            bonusDisplayLabel.Text = "";
            requiredHoursDisplayLabel.Text = "";
            attendedHoursDisplayLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the program
            this.Close();
        }
    }
}
