﻿namespace TeamLeader
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.displayButton = new System.Windows.Forms.Button();
            this.outputGroupBox = new System.Windows.Forms.GroupBox();
            this.attendedHoursDisplayLabel = new System.Windows.Forms.Label();
            this.requiredHoursDisplayLabel = new System.Windows.Forms.Label();
            this.bonusDisplayLabel = new System.Windows.Forms.Label();
            this.payRateDisplayLabel = new System.Windows.Forms.Label();
            this.shiftDisplayLabel = new System.Windows.Forms.Label();
            this.numberDisplayLabel = new System.Windows.Forms.Label();
            this.nameDisplayLabel = new System.Windows.Forms.Label();
            this.inputGroupBox = new System.Windows.Forms.GroupBox();
            this.attendedHoursTextBox = new System.Windows.Forms.TextBox();
            this.requiredHoursTextBox = new System.Windows.Forms.TextBox();
            this.bonusLabel = new System.Windows.Forms.Label();
            this.bonusTextBox = new System.Windows.Forms.TextBox();
            this.requiredHoursLabel = new System.Windows.Forms.Label();
            this.attendedHoursLabel = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.payRateTextBox = new System.Windows.Forms.TextBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.shiftTextBox = new System.Windows.Forms.TextBox();
            this.numberLabel = new System.Windows.Forms.Label();
            this.numberTextBox = new System.Windows.Forms.TextBox();
            this.shiftLabel = new System.Windows.Forms.Label();
            this.payRateLabel = new System.Windows.Forms.Label();
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.outputGroupBox.SuspendLayout();
            this.inputGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(138, 287);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(75, 23);
            this.displayButton.TabIndex = 13;
            this.displayButton.Text = "Display";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // outputGroupBox
            // 
            this.outputGroupBox.Controls.Add(this.attendedHoursDisplayLabel);
            this.outputGroupBox.Controls.Add(this.requiredHoursDisplayLabel);
            this.outputGroupBox.Controls.Add(this.bonusDisplayLabel);
            this.outputGroupBox.Controls.Add(this.payRateDisplayLabel);
            this.outputGroupBox.Controls.Add(this.shiftDisplayLabel);
            this.outputGroupBox.Controls.Add(this.numberDisplayLabel);
            this.outputGroupBox.Controls.Add(this.nameDisplayLabel);
            this.outputGroupBox.Location = new System.Drawing.Point(512, 12);
            this.outputGroupBox.Name = "outputGroupBox";
            this.outputGroupBox.Size = new System.Drawing.Size(365, 269);
            this.outputGroupBox.TabIndex = 12;
            this.outputGroupBox.TabStop = false;
            this.outputGroupBox.Text = "Output";
            // 
            // attendedHoursDisplayLabel
            // 
            this.attendedHoursDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.attendedHoursDisplayLabel.Location = new System.Drawing.Point(19, 230);
            this.attendedHoursDisplayLabel.Name = "attendedHoursDisplayLabel";
            this.attendedHoursDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.attendedHoursDisplayLabel.TabIndex = 6;
            // 
            // requiredHoursDisplayLabel
            // 
            this.requiredHoursDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.requiredHoursDisplayLabel.Location = new System.Drawing.Point(19, 193);
            this.requiredHoursDisplayLabel.Name = "requiredHoursDisplayLabel";
            this.requiredHoursDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.requiredHoursDisplayLabel.TabIndex = 5;
            // 
            // bonusDisplayLabel
            // 
            this.bonusDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bonusDisplayLabel.Location = new System.Drawing.Point(19, 157);
            this.bonusDisplayLabel.Name = "bonusDisplayLabel";
            this.bonusDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.bonusDisplayLabel.TabIndex = 4;
            // 
            // payRateDisplayLabel
            // 
            this.payRateDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.payRateDisplayLabel.Location = new System.Drawing.Point(19, 126);
            this.payRateDisplayLabel.Name = "payRateDisplayLabel";
            this.payRateDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.payRateDisplayLabel.TabIndex = 3;
            // 
            // shiftDisplayLabel
            // 
            this.shiftDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.shiftDisplayLabel.Location = new System.Drawing.Point(19, 89);
            this.shiftDisplayLabel.Name = "shiftDisplayLabel";
            this.shiftDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.shiftDisplayLabel.TabIndex = 2;
            // 
            // numberDisplayLabel
            // 
            this.numberDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberDisplayLabel.Location = new System.Drawing.Point(19, 53);
            this.numberDisplayLabel.Name = "numberDisplayLabel";
            this.numberDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.numberDisplayLabel.TabIndex = 1;
            // 
            // nameDisplayLabel
            // 
            this.nameDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nameDisplayLabel.Location = new System.Drawing.Point(19, 22);
            this.nameDisplayLabel.Name = "nameDisplayLabel";
            this.nameDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.nameDisplayLabel.TabIndex = 0;
            // 
            // inputGroupBox
            // 
            this.inputGroupBox.Controls.Add(this.attendedHoursTextBox);
            this.inputGroupBox.Controls.Add(this.requiredHoursTextBox);
            this.inputGroupBox.Controls.Add(this.bonusLabel);
            this.inputGroupBox.Controls.Add(this.bonusTextBox);
            this.inputGroupBox.Controls.Add(this.requiredHoursLabel);
            this.inputGroupBox.Controls.Add(this.attendedHoursLabel);
            this.inputGroupBox.Controls.Add(this.nameTextBox);
            this.inputGroupBox.Controls.Add(this.payRateTextBox);
            this.inputGroupBox.Controls.Add(this.nameLabel);
            this.inputGroupBox.Controls.Add(this.shiftTextBox);
            this.inputGroupBox.Controls.Add(this.numberLabel);
            this.inputGroupBox.Controls.Add(this.numberTextBox);
            this.inputGroupBox.Controls.Add(this.shiftLabel);
            this.inputGroupBox.Controls.Add(this.payRateLabel);
            this.inputGroupBox.Location = new System.Drawing.Point(12, 12);
            this.inputGroupBox.Name = "inputGroupBox";
            this.inputGroupBox.Size = new System.Drawing.Size(485, 269);
            this.inputGroupBox.TabIndex = 11;
            this.inputGroupBox.TabStop = false;
            this.inputGroupBox.Text = "Input";
            // 
            // attendedHoursTextBox
            // 
            this.attendedHoursTextBox.Location = new System.Drawing.Point(126, 227);
            this.attendedHoursTextBox.Name = "attendedHoursTextBox";
            this.attendedHoursTextBox.Size = new System.Drawing.Size(336, 20);
            this.attendedHoursTextBox.TabIndex = 13;
            // 
            // requiredHoursTextBox
            // 
            this.requiredHoursTextBox.Location = new System.Drawing.Point(126, 190);
            this.requiredHoursTextBox.Name = "requiredHoursTextBox";
            this.requiredHoursTextBox.Size = new System.Drawing.Size(336, 20);
            this.requiredHoursTextBox.TabIndex = 12;
            // 
            // bonusLabel
            // 
            this.bonusLabel.AutoSize = true;
            this.bonusLabel.Location = new System.Drawing.Point(40, 157);
            this.bonusLabel.Name = "bonusLabel";
            this.bonusLabel.Size = new System.Drawing.Size(80, 13);
            this.bonusLabel.TabIndex = 8;
            this.bonusLabel.Text = "Monthly Bonus:";
            // 
            // bonusTextBox
            // 
            this.bonusTextBox.Location = new System.Drawing.Point(126, 154);
            this.bonusTextBox.Name = "bonusTextBox";
            this.bonusTextBox.Size = new System.Drawing.Size(336, 20);
            this.bonusTextBox.TabIndex = 11;
            // 
            // requiredHoursLabel
            // 
            this.requiredHoursLabel.AutoSize = true;
            this.requiredHoursLabel.Location = new System.Drawing.Point(36, 193);
            this.requiredHoursLabel.Name = "requiredHoursLabel";
            this.requiredHoursLabel.Size = new System.Drawing.Size(84, 13);
            this.requiredHoursLabel.TabIndex = 9;
            this.requiredHoursLabel.Text = "Required Hours:";
            // 
            // attendedHoursLabel
            // 
            this.attendedHoursLabel.AutoSize = true;
            this.attendedHoursLabel.Location = new System.Drawing.Point(36, 230);
            this.attendedHoursLabel.Name = "attendedHoursLabel";
            this.attendedHoursLabel.Size = new System.Drawing.Size(84, 13);
            this.attendedHoursLabel.TabIndex = 10;
            this.attendedHoursLabel.Text = "Attended Hours:";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(126, 19);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(336, 20);
            this.nameTextBox.TabIndex = 4;
            // 
            // payRateTextBox
            // 
            this.payRateTextBox.Location = new System.Drawing.Point(126, 124);
            this.payRateTextBox.Name = "payRateTextBox";
            this.payRateTextBox.Size = new System.Drawing.Size(336, 20);
            this.payRateTextBox.TabIndex = 7;
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(79, 22);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(41, 13);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Name: ";
            // 
            // shiftTextBox
            // 
            this.shiftTextBox.Location = new System.Drawing.Point(126, 87);
            this.shiftTextBox.Name = "shiftTextBox";
            this.shiftTextBox.Size = new System.Drawing.Size(336, 20);
            this.shiftTextBox.TabIndex = 6;
            // 
            // numberLabel
            // 
            this.numberLabel.AutoSize = true;
            this.numberLabel.Location = new System.Drawing.Point(21, 54);
            this.numberLabel.Name = "numberLabel";
            this.numberLabel.Size = new System.Drawing.Size(99, 13);
            this.numberLabel.TabIndex = 1;
            this.numberLabel.Text = "Employee Number: ";
            // 
            // numberTextBox
            // 
            this.numberTextBox.Location = new System.Drawing.Point(126, 51);
            this.numberTextBox.Name = "numberTextBox";
            this.numberTextBox.Size = new System.Drawing.Size(336, 20);
            this.numberTextBox.TabIndex = 5;
            // 
            // shiftLabel
            // 
            this.shiftLabel.AutoSize = true;
            this.shiftLabel.Location = new System.Drawing.Point(10, 90);
            this.shiftLabel.Name = "shiftLabel";
            this.shiftLabel.Size = new System.Drawing.Size(110, 13);
            this.shiftLabel.TabIndex = 2;
            this.shiftLabel.Text = "Shift Number (1 or 2): ";
            // 
            // payRateLabel
            // 
            this.payRateLabel.AutoSize = true;
            this.payRateLabel.Location = new System.Drawing.Point(30, 127);
            this.payRateLabel.Name = "payRateLabel";
            this.payRateLabel.Size = new System.Drawing.Size(90, 13);
            this.payRateLabel.TabIndex = 3;
            this.payRateLabel.Text = "Hourly Pay Rate: ";
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(465, 287);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 23);
            this.resetButton.TabIndex = 14;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(796, 287);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 15;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(898, 339);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.outputGroupBox);
            this.Controls.Add(this.inputGroupBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.outputGroupBox.ResumeLayout(false);
            this.inputGroupBox.ResumeLayout(false);
            this.inputGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.GroupBox outputGroupBox;
        private System.Windows.Forms.Label payRateDisplayLabel;
        private System.Windows.Forms.Label shiftDisplayLabel;
        private System.Windows.Forms.Label numberDisplayLabel;
        private System.Windows.Forms.Label nameDisplayLabel;
        private System.Windows.Forms.GroupBox inputGroupBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox payRateTextBox;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.TextBox shiftTextBox;
        private System.Windows.Forms.Label numberLabel;
        private System.Windows.Forms.TextBox numberTextBox;
        private System.Windows.Forms.Label shiftLabel;
        private System.Windows.Forms.Label payRateLabel;
        private System.Windows.Forms.TextBox attendedHoursTextBox;
        private System.Windows.Forms.TextBox requiredHoursTextBox;
        private System.Windows.Forms.Label bonusLabel;
        private System.Windows.Forms.TextBox bonusTextBox;
        private System.Windows.Forms.Label requiredHoursLabel;
        private System.Windows.Forms.Label attendedHoursLabel;
        private System.Windows.Forms.Label attendedHoursDisplayLabel;
        private System.Windows.Forms.Label requiredHoursDisplayLabel;
        private System.Windows.Forms.Label bonusDisplayLabel;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button exitButton;
    }
}

