﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamLeader
{
    class TeamLeader : ProductionWorker
    {
        // Fields for the class
        private decimal _monthlyBonus;
        private int _requiredHours;
        private int _attendedHours;


        // No-arg constructor
        public TeamLeader()
        {
            _monthlyBonus = 0m;
            _requiredHours = 0;
            _attendedHours = 0;
        }

        // Constructor with two parameters
        public TeamLeader(decimal monthlyBonus, int requiredHours, int attendedHours)
        {
            _monthlyBonus = monthlyBonus;
            _requiredHours = requiredHours;
            _attendedHours = attendedHours;
        }

        // Gets information for the monthly bonus variable
        public decimal MonthlyBonus
        {
            get { return _monthlyBonus; }
            set { _monthlyBonus = value; }
        }

        // Gets information for the required hours variable
        public int RequiredHours
        {
            get { return _requiredHours; }
            set { _requiredHours = value; }
        }

        // Gets information for the attended hours variable
        public int AttendedHours
        {
            get { return _attendedHours; }
            set { _attendedHours = value; }
        }
    }
}
