﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamLeader
{
    class Employee
    {
        // Fields for the class
        private string _name;
        private string _number;

        // No-arg constructor
        public Employee()
        {
            _name = "";
            _number = "";
        }

        // Constructor with two parameters
        public Employee(string Name, string Number)
        {
            _name = Name;
            _number = Number;
        }

        // Gets information for the name variable
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        // Gets information for the number variable
        public string Number
        {
            get { return _number; }
            set { _number = value; }
        }
    }
}
