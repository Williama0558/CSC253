﻿/**
* 11/4/18
* CSC 253
* Aaron Williams
* This program holds information in a class for production workers
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_and_ProductionWorker_Classes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            // Variables that will be passed into classes
            double payRate = 0.0;
            int shiftNumber = 0;

            // Creates a production worker object and initializes some variables
            ProductionWorker worker = new ProductionWorker();
            worker.Name = nameTextBox.Text;
            worker.Number = numberTextBox.Text;

            // Checks to make sure proper input is entered in the shiftNumber field.
            if (int.TryParse(shiftTextBox.Text, out shiftNumber))
            {
                if (shiftNumber == 1 || shiftNumber == 2)
                {
                    worker.ShiftNumber = int.Parse(shiftTextBox.Text);
                }
                else
                {
                    MessageBox.Show("Invalid shift number entered");
                }
            }
            else
            {
                MessageBox.Show("Invalid input for shift number entered");
            }

            // Checks to make sure proper input is entered in the pay rate field.
            if (double.TryParse(payRateTextBox.Text, out payRate))
            {
                worker.PayRate = double.Parse(payRateTextBox.Text);
            }
            else
            {
                MessageBox.Show("Invalid input for pay rate entered");
            }

            // Displays output
            nameDisplayLabel.Text = worker.Name;
            numberDisplayLabel.Text = worker.Number;
            shiftDisplayLabel.Text = worker.ShiftNumber.ToString();
            payRateDisplayLabel.Text = worker.PayRate.ToString();
        }
    }
}
