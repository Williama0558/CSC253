﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_and_ProductionWorker_Classes
{
    class ProductionWorker : Employee
    {
        // Fields for the class
        private int _shiftNumber;
        private double _hourlyPayRate;


        // No-arg constructor
        public ProductionWorker()
        {
            _shiftNumber = 0;
            _hourlyPayRate = 0.0;
        }

        // Constructor with two parameters
        public ProductionWorker(int ShiftNumber, double PayRate)
        {
            _shiftNumber = ShiftNumber;
            _hourlyPayRate = PayRate;
        }

        // Gets information for the shift number variable
        public int ShiftNumber
        {
            get { return _shiftNumber; }
            set { _shiftNumber = value; }
        }

        // Gets information for the pay rate variable
        public double PayRate
        {
            get { return _hourlyPayRate; }
            set { _hourlyPayRate = value; }
        }
    }
}
