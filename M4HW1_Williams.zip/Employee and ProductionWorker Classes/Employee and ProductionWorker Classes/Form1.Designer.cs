﻿namespace Employee_and_ProductionWorker_Classes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLabel = new System.Windows.Forms.Label();
            this.numberLabel = new System.Windows.Forms.Label();
            this.shiftLabel = new System.Windows.Forms.Label();
            this.payRateLabel = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.numberTextBox = new System.Windows.Forms.TextBox();
            this.shiftTextBox = new System.Windows.Forms.TextBox();
            this.payRateTextBox = new System.Windows.Forms.TextBox();
            this.inputGroupBox = new System.Windows.Forms.GroupBox();
            this.outputGroupBox = new System.Windows.Forms.GroupBox();
            this.payRateDisplayLabel = new System.Windows.Forms.Label();
            this.shiftDisplayLabel = new System.Windows.Forms.Label();
            this.numberDisplayLabel = new System.Windows.Forms.Label();
            this.nameDisplayLabel = new System.Windows.Forms.Label();
            this.displayButton = new System.Windows.Forms.Button();
            this.inputGroupBox.SuspendLayout();
            this.outputGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(79, 22);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(41, 13);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Name: ";
            // 
            // numberLabel
            // 
            this.numberLabel.AutoSize = true;
            this.numberLabel.Location = new System.Drawing.Point(21, 54);
            this.numberLabel.Name = "numberLabel";
            this.numberLabel.Size = new System.Drawing.Size(99, 13);
            this.numberLabel.TabIndex = 1;
            this.numberLabel.Text = "Employee Number: ";
            // 
            // shiftLabel
            // 
            this.shiftLabel.AutoSize = true;
            this.shiftLabel.Location = new System.Drawing.Point(10, 90);
            this.shiftLabel.Name = "shiftLabel";
            this.shiftLabel.Size = new System.Drawing.Size(110, 13);
            this.shiftLabel.TabIndex = 2;
            this.shiftLabel.Text = "Shift Number (1 or 2): ";
            // 
            // payRateLabel
            // 
            this.payRateLabel.AutoSize = true;
            this.payRateLabel.Location = new System.Drawing.Point(30, 127);
            this.payRateLabel.Name = "payRateLabel";
            this.payRateLabel.Size = new System.Drawing.Size(90, 13);
            this.payRateLabel.TabIndex = 3;
            this.payRateLabel.Text = "Hourly Pay Rate: ";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(126, 19);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(336, 20);
            this.nameTextBox.TabIndex = 4;
            // 
            // numberTextBox
            // 
            this.numberTextBox.Location = new System.Drawing.Point(126, 51);
            this.numberTextBox.Name = "numberTextBox";
            this.numberTextBox.Size = new System.Drawing.Size(336, 20);
            this.numberTextBox.TabIndex = 5;
            // 
            // shiftTextBox
            // 
            this.shiftTextBox.Location = new System.Drawing.Point(126, 87);
            this.shiftTextBox.Name = "shiftTextBox";
            this.shiftTextBox.Size = new System.Drawing.Size(336, 20);
            this.shiftTextBox.TabIndex = 6;
            // 
            // payRateTextBox
            // 
            this.payRateTextBox.Location = new System.Drawing.Point(126, 124);
            this.payRateTextBox.Name = "payRateTextBox";
            this.payRateTextBox.Size = new System.Drawing.Size(336, 20);
            this.payRateTextBox.TabIndex = 7;
            // 
            // inputGroupBox
            // 
            this.inputGroupBox.Controls.Add(this.nameTextBox);
            this.inputGroupBox.Controls.Add(this.payRateTextBox);
            this.inputGroupBox.Controls.Add(this.nameLabel);
            this.inputGroupBox.Controls.Add(this.shiftTextBox);
            this.inputGroupBox.Controls.Add(this.numberLabel);
            this.inputGroupBox.Controls.Add(this.numberTextBox);
            this.inputGroupBox.Controls.Add(this.shiftLabel);
            this.inputGroupBox.Controls.Add(this.payRateLabel);
            this.inputGroupBox.Location = new System.Drawing.Point(12, 12);
            this.inputGroupBox.Name = "inputGroupBox";
            this.inputGroupBox.Size = new System.Drawing.Size(485, 164);
            this.inputGroupBox.TabIndex = 8;
            this.inputGroupBox.TabStop = false;
            this.inputGroupBox.Text = "Input";
            // 
            // outputGroupBox
            // 
            this.outputGroupBox.Controls.Add(this.payRateDisplayLabel);
            this.outputGroupBox.Controls.Add(this.shiftDisplayLabel);
            this.outputGroupBox.Controls.Add(this.numberDisplayLabel);
            this.outputGroupBox.Controls.Add(this.nameDisplayLabel);
            this.outputGroupBox.Location = new System.Drawing.Point(512, 12);
            this.outputGroupBox.Name = "outputGroupBox";
            this.outputGroupBox.Size = new System.Drawing.Size(365, 164);
            this.outputGroupBox.TabIndex = 9;
            this.outputGroupBox.TabStop = false;
            this.outputGroupBox.Text = "Output";
            // 
            // payRateDisplayLabel
            // 
            this.payRateDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.payRateDisplayLabel.Location = new System.Drawing.Point(19, 126);
            this.payRateDisplayLabel.Name = "payRateDisplayLabel";
            this.payRateDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.payRateDisplayLabel.TabIndex = 3;
            // 
            // shiftDisplayLabel
            // 
            this.shiftDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.shiftDisplayLabel.Location = new System.Drawing.Point(19, 89);
            this.shiftDisplayLabel.Name = "shiftDisplayLabel";
            this.shiftDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.shiftDisplayLabel.TabIndex = 2;
            // 
            // numberDisplayLabel
            // 
            this.numberDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberDisplayLabel.Location = new System.Drawing.Point(19, 53);
            this.numberDisplayLabel.Name = "numberDisplayLabel";
            this.numberDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.numberDisplayLabel.TabIndex = 1;
            // 
            // nameDisplayLabel
            // 
            this.nameDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nameDisplayLabel.Location = new System.Drawing.Point(19, 22);
            this.nameDisplayLabel.Name = "nameDisplayLabel";
            this.nameDisplayLabel.Size = new System.Drawing.Size(340, 23);
            this.nameDisplayLabel.TabIndex = 0;
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(138, 197);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(75, 23);
            this.displayButton.TabIndex = 10;
            this.displayButton.Text = "Display";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(889, 243);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.outputGroupBox);
            this.Controls.Add(this.inputGroupBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.inputGroupBox.ResumeLayout(false);
            this.inputGroupBox.PerformLayout();
            this.outputGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label numberLabel;
        private System.Windows.Forms.Label shiftLabel;
        private System.Windows.Forms.Label payRateLabel;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox numberTextBox;
        private System.Windows.Forms.TextBox shiftTextBox;
        private System.Windows.Forms.TextBox payRateTextBox;
        private System.Windows.Forms.GroupBox inputGroupBox;
        private System.Windows.Forms.GroupBox outputGroupBox;
        private System.Windows.Forms.Label payRateDisplayLabel;
        private System.Windows.Forms.Label shiftDisplayLabel;
        private System.Windows.Forms.Label numberDisplayLabel;
        private System.Windows.Forms.Label nameDisplayLabel;
        private System.Windows.Forms.Button displayButton;
    }
}

