﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Catacombs_of_Bool
{
    class Rooms
    {
        // Fields for the Rooms class
        private string _roomName;
        private string _roomDescription;
        private string _roomExits;
        private Monster _roomMonsters;

        public Rooms()
        {
            string _roomName = "";
            string _roomDescription = "";
            string _roomExits = "";
            Monster _roomMonsters;
        }

        public Rooms(string roomName, string roomDescription, string roomExits, Monster roomMonsters)
        {
            string _roomName = roomName;
            string _roomDescription = roomDescription;
            string _roomExits = roomExits;
            Monster _roomMonsters = roomMonsters;
        }

        public string roomName
        {
            get { return _roomName; }
            set { _roomName = value; }
        }

        public string roomDescription
        {
            get { return _roomDescription; }
            set { _roomDescription = value; }
        }

        public string roomExits
        {
            get { return _roomExits; }
            set { _roomExits = value; }
        }

        public Monster roomMonsters
        {
            get { return _roomMonsters; }
            set { _roomMonsters = value; }
        }
    }

}
