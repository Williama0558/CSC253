﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Catacombs_of_Bool
{
    class ItemGeneration
    {
        public static StreamReader itemFile;

        public static List<Items> createItems()
        {
            // Will look for the correct text file and will create item objects using that information.

            // Will fix file reading in next module when everything is moved to databases
            itemFile = File.OpenText("Items\\IronBoots.txt");
            Items boots = new Items();
            boots.name = itemFile.ReadLine();
            boots.description = itemFile.ReadLine();
            itemFile.Close();

            itemFile = File.OpenText("Items\\IronBuckler.txt");
            Items buckler = new Items();
            buckler.name = itemFile.ReadLine();
            buckler.description = itemFile.ReadLine();
            itemFile.Close();

            itemFile = File.OpenText("Items\\IronChest.txt");
            Items chestpiece = new Items();
            chestpiece.name = itemFile.ReadLine();
            chestpiece.description = itemFile.ReadLine();
            itemFile.Close();

            itemFile = File.OpenText("Items\\Mittens.txt");
            Items mittens = new Items();
            mittens.name = itemFile.ReadLine();
            mittens.description = itemFile.ReadLine();
            itemFile.Close();


            // Returns a list of mobs created from this method
            List<Items> itemList = new List<Items> { boots, buckler, chestpiece, mittens };
            return itemList;
        }
    }
}
