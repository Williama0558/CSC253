﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Catacombs_of_Bool
{
    class Items : BaseItem
    {

        public Items() : base()
        {
            // Gets variables from the base class

        }

        public Items(string name, string description) : base(name, description)
        {
            // Constructor that takes arguments for each field

        }

    }
}
