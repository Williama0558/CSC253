﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Catacombs_of_Bool
{

    class Combat
    {
        // This class controls the fighting mechanics of the game.
        public static void getCombatants(Player player, Monster monster)
        {
            Random rng = new Random();
            Console.WriteLine("\n\n");
            while (player.health > 0 && monster.health > 0)
            {
                // Displays status to the player
                Console.WriteLine("You are currently fighting " + monster.name + "\n");
                Console.WriteLine("You currently have " + player.health + " hitpoints\n");
                Console.WriteLine("It currently has " + monster.health + " hitpoints\n");
                Console.WriteLine("Type in 'attack' to attack the enemy\n");
                Input combatChoice = new Input();
                combatChoice.userInput = Console.ReadLine().ToUpper();

                // Checks to see if the player hits and for how much.
                if (combatChoice.userInput == "ATTACK")
                {
                    int hitChance = rng.Next(1, 10);
                    if (hitChance >= monster.agility)
                    {
                        int damage = rng.Next(monster.armorValue, 20);
                        monster.health -= damage;
                        Console.WriteLine("You hit the " + monster.name + " for " + damage + " hitpoints\n");
                    }
                    else
                    {
                        Console.WriteLine("You missed the " + monster.name);
                    }
                }

                // Checks to see if the enemy hits and for how much
                int enemyHitchance = rng.Next(1, 20);
                if (enemyHitchance >= player.agility)
                {
                    int damage = rng.Next(player.armorValue, 15);
                    player.health -= damage;
                    Console.WriteLine("The " + monster.name + " hit you for " + damage + " hitpoints\n");
                }
                else
                {
                    Console.WriteLine("The " + monster.name + " missed\n");
                }

            }

            // Displays a message depending on who wins.
            if (player.health <= 0)
            {
                Console.WriteLine("You died, game over");
                Environment.Exit(0);
            }
            else
            {
                Console.WriteLine("You defeated the " + monster.name);
            }
        }
    }
}
