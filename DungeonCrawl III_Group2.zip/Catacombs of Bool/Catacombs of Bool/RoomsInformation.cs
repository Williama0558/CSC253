﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Catacombs_of_Bool
{
    class RoomsInformation
    {
        public static StreamReader roomFile;
        public static List<Monster> mobList = MonsterGeneration.createMonsters();

        public static Rooms[,] createRoomsArray()
        {
            // Method that reads info from various files and then stores it in Room objects

            // Will fix file reading in next module when everything is moved to databases
            roomFile = File.OpenText("Rooms\\Entrance.txt");
            Rooms entrance = new Rooms();
            entrance.roomName = roomFile.ReadLine();
            entrance.roomDescription = roomFile.ReadLine();
            entrance.roomExits = roomFile.ReadLine();
            entrance.roomMonsters = new Monster(mobList[0].name, mobList[0].health, mobList[0].agility, mobList[0].armorValue, mobList[0].description);
            roomFile.Close();

            roomFile = File.OpenText("Rooms\\NorthHall.txt");
            Rooms northHall = new Rooms();
            northHall.roomName = roomFile.ReadLine();
            northHall.roomDescription = roomFile.ReadLine();
            northHall.roomExits = roomFile.ReadLine();
            northHall.roomMonsters = new Monster(mobList[0].name, mobList[0].health, mobList[0].agility, mobList[0].armorValue, mobList[0].description);
            roomFile.Close();

            roomFile = File.OpenText("Rooms\\EmptyRoom.txt");
            Rooms emptyRoom = new Rooms();
            emptyRoom.roomName = roomFile.ReadLine();
            emptyRoom.roomDescription = roomFile.ReadLine();
            emptyRoom.roomExits = roomFile.ReadLine();
            emptyRoom.roomMonsters = new Monster(mobList[0].name, mobList[0].health, mobList[0].agility, mobList[0].armorValue, mobList[0].description);
            roomFile.Close();

            roomFile = File.OpenText("Rooms\\TreasureStash.txt");
            Rooms treasureStash = new Rooms();
            treasureStash.roomName = roomFile.ReadLine();
            treasureStash.roomDescription = roomFile.ReadLine();
            treasureStash.roomExits = roomFile.ReadLine();
            roomFile.Close();

            roomFile = File.OpenText("Rooms\\CentralHall.txt");
            Rooms centralHall = new Rooms();
            centralHall.roomName = roomFile.ReadLine();
            centralHall.roomDescription = roomFile.ReadLine();
            centralHall.roomExits = roomFile.ReadLine();
            roomFile.Close();

            roomFile = File.OpenText("Rooms\\Armory.txt");
            Rooms armory = new Rooms();
            armory.roomName = roomFile.ReadLine();
            armory.roomDescription = roomFile.ReadLine();
            armory.roomExits = roomFile.ReadLine();
            roomFile.Close();

            roomFile = File.OpenText("Rooms\\BossRoom.txt");
            Rooms bossRoom = new Rooms();
            bossRoom.roomName = roomFile.ReadLine();
            bossRoom.roomDescription = roomFile.ReadLine();
            bossRoom.roomExits = roomFile.ReadLine();
            roomFile.Close();

            roomFile = File.OpenText("Rooms\\SouthHall.txt");
            Rooms southHall = new Rooms();
            southHall.roomName = roomFile.ReadLine();
            southHall.roomDescription = roomFile.ReadLine();
            southHall.roomExits = roomFile.ReadLine();
            roomFile.Close();

            roomFile = File.OpenText("Rooms\\Exit.txt");
            Rooms exit = new Rooms();
            exit.roomName = roomFile.ReadLine();
            exit.roomDescription = roomFile.ReadLine();
            exit.roomExits = roomFile.ReadLine();
            roomFile.Close();

            // Creates an array to store room class objects
            Rooms[,] roomsArray = { { entrance, northHall, emptyRoom },
                                     { treasureStash, centralHall, armory },
                                     {  bossRoom, southHall, exit} };

            return roomsArray;
        }
    }
}
