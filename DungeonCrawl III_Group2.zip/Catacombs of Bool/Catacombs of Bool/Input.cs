﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Catacombs_of_Bool
{
    class Input
    {
        // Class for holding input the user enters in
        public string userInput { get; set; }
    }
}
