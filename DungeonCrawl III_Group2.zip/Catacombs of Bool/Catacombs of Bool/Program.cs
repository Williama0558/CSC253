﻿/**
* 11/25/2018
* CSC 253
* Group 2

* Group Members: Aaron Williams
* This program is a dungeon crawl game where the player can get loot, fight monsters, and explore a dungeon.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Catacombs_of_Bool
{
    class Program
    {
        static void Main(string[] args)
        {
            // Goes to class that starts the game
            Start_Game.gameStart();
        }

    }
}