﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Catacombs_of_Bool
{
    class MonsterGeneration
    {
        public static StreamReader monsterFile;

        public static List<Monster> createMonsters()
        {
            // Will look for the correct text file and will creates monster objects using that information.

            // Will fix file reading in next module when everything is moved to databases
            monsterFile = File.OpenText("Monsters\\Goblin.txt");
            Monster goblin = new Monster();
            goblin.name = monsterFile.ReadLine();
            goblin.description = monsterFile.ReadLine();
            goblin.health = int.Parse(monsterFile.ReadLine());
            goblin.agility = int.Parse(monsterFile.ReadLine());
            goblin.armorValue = int.Parse(monsterFile.ReadLine());
            monsterFile.Close();

            monsterFile = File.OpenText("Monsters\\Spider.txt");
            Monster spider = new Monster();
            spider.name = monsterFile.ReadLine();
            spider.description = monsterFile.ReadLine();
            spider.health = int.Parse(monsterFile.ReadLine());
            spider.agility = int.Parse(monsterFile.ReadLine());
            spider.armorValue = int.Parse(monsterFile.ReadLine());
            monsterFile.Close();

            monsterFile = File.OpenText("Monsters\\Servant.txt");
            Monster servant = new Monster();
            servant.name = monsterFile.ReadLine();
            servant.description = monsterFile.ReadLine();
            servant.health = int.Parse(monsterFile.ReadLine());
            servant.agility = int.Parse(monsterFile.ReadLine());
            servant.armorValue = int.Parse(monsterFile.ReadLine());
            monsterFile.Close();

            monsterFile = File.OpenText("Monsters\\GiantRat.txt");
            Monster rat = new Monster();
            rat.name = monsterFile.ReadLine();
            rat.description = monsterFile.ReadLine();
            rat.health = int.Parse(monsterFile.ReadLine());
            rat.agility = int.Parse(monsterFile.ReadLine());
            rat.armorValue = int.Parse(monsterFile.ReadLine());
            monsterFile.Close();

            monsterFile = File.OpenText("Monsters\\AnimatedArmor.txt");
            Monster armor = new Monster();
            armor.name = monsterFile.ReadLine();
            armor.description = monsterFile.ReadLine();
            armor.health = int.Parse(monsterFile.ReadLine());
            armor.agility = int.Parse(monsterFile.ReadLine());
            armor.armorValue = int.Parse(monsterFile.ReadLine());
            monsterFile.Close();

            // Returns a list of mobs created from this method
            List < Monster > mobList = new List<Monster> { goblin, spider, servant, rat, armor };
            return mobList;
        }
    }
}
